/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import { LetterFormEditor } from './components/LetterFormEditor';
import { LetterPreview } from './components/LetterPreview';
import { ReferenceAnalysisView } from './components/ReferenceAnalysisView';
import { TemplateLibraryView } from './components/TemplateLibraryView';
import { TopBar } from './components/TopBar';
import { DEFAULT_MARGINS, REFERENCE_LETTER } from './data/referenceLetter';
import { ActiveWorkspaceTab, LetterDocument } from './types/letter';

const STORAGE_ACTIVE_KEY = 'naskah_dinas_active_doc_v1';
const STORAGE_DRAFTS_KEY = 'naskah_dinas_saved_drafts_v1';

function withDefaultMargins(doc: LetterDocument): LetterDocument {
  return {
    ...doc,
    margins: doc.margins ? { ...DEFAULT_MARGINS, ...doc.margins } : { ...DEFAULT_MARGINS },
  };
}

function loadInitialActiveDoc(): LetterDocument {
  try {
    const raw = localStorage.getItem(STORAGE_ACTIVE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as LetterDocument;
      if (parsed && parsed.kop && parsed.identitas && Array.isArray(parsed.direktifList)) {
        return withDefaultMargins(parsed);
      }
    }
  } catch {
    // Fallback to reference letter
  }
  return structuredClone(REFERENCE_LETTER);
}

function loadSavedDrafts(): LetterDocument[] {
  try {
    const raw = localStorage.getItem(STORAGE_DRAFTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as LetterDocument[];
      if (Array.isArray(parsed)) {
        return parsed.map(withDefaultMargins);
      }
    }
  } catch {
    // Fallback to empty array
  }
  return [];
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveWorkspaceTab>('editor');
  const [mobilePane, setMobilePane] = useState<'form' | 'preview'>('form');
  const [activeDoc, setActiveDoc] = useState<LetterDocument>(loadInitialActiveDoc);
  const [savedDrafts, setSavedDrafts] = useState<LetterDocument[]>(loadSavedDrafts);
  const [draftSavedJustNow, setDraftSavedJustNow] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_ACTIVE_KEY, JSON.stringify(activeDoc));
    } catch {
      // Ignore storage quota errors
    }
  }, [activeDoc]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_DRAFTS_KEY, JSON.stringify(savedDrafts));
    } catch {
      // Ignore storage quota errors
    }
  }, [savedDrafts]);

  const handleSaveDraft = () => {
    const today = new Date().toISOString().slice(0, 10);
    const isPresetId = activeDoc.id.startsWith('ref-') || activeDoc.id.startsWith('tpl-');
    const draftToSave: LetterDocument = {
      ...structuredClone(activeDoc),
      id: isPresetId ? `draft-${Date.now()}` : activeDoc.id,
      updatedAt: today,
    };

    setActiveDoc(draftToSave);
    setSavedDrafts((prev) => {
      const exists = prev.some((d) => d.id === draftToSave.id);
      if (exists) {
        return prev.map((d) => (d.id === draftToSave.id ? draftToSave : d));
      }
      return [draftToSave, ...prev];
    });

    setDraftSavedJustNow(true);
    setTimeout(() => setDraftSavedJustNow(false), 2000);
  };

  const handleLoadDocument = (doc: LetterDocument) => {
    setActiveDoc(structuredClone(doc));
    setActiveTab('editor');
  };

  const handleDuplicateAsNew = (doc: LetterDocument) => {
    const today = new Date().toISOString().slice(0, 10);
    const cloned: LetterDocument = {
      ...structuredClone(doc),
      id: `draft-${Date.now()}`,
      title: `${doc.title} (Salinan)`,
      updatedAt: today,
    };
    setSavedDrafts((prev) => [cloned, ...prev]);
    setActiveDoc(cloned);
    setActiveTab('editor');
  };

  const handleDeleteDraft = (id: string) => {
    setSavedDrafts((prev) => prev.filter((d) => d.id !== id));
  };

  const handleImportJson = (doc: LetterDocument) => {
    setSavedDrafts((prev) => [doc, ...prev]);
    setActiveDoc(doc);
    setActiveTab('editor');
  };

  const handleUseReferenceAsTemplate = () => {
    setActiveDoc(structuredClone(REFERENCE_LETTER));
    setActiveTab('editor');
  };

  const handlePrint = () => {
    if (activeTab !== 'editor') {
      setActiveTab('editor');
      setMobilePane('preview');
      requestAnimationFrame(() => {
        setTimeout(() => window.print(), 80);
      });
      return;
    }
    window.print();
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onPrint={handlePrint}
      />

      {activeTab === 'editor' && (
        <main className="flex-1 flex flex-col md:h-[calc(100vh-3.5rem)] md:overflow-hidden">
          {/* Mobile Pane Switcher (below md) */}
          <div className="no-print md:hidden px-4 py-2 bg-white border-b border-slate-200 flex items-center gap-1">
            <button
              type="button"
              onClick={() => setMobilePane('form')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                mobilePane === 'form'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              Isi Data Surat
            </button>
            <button
              type="button"
              onClick={() => setMobilePane('preview')}
              className={`flex-1 py-1.5 text-xs font-medium rounded-md cursor-pointer ${
                mobilePane === 'preview'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-600'
              }`}
            >
              Pratinjau A4
            </button>
          </div>

          <div className="flex-1 flex flex-col md:flex-row md:overflow-hidden">
            <aside
              className={`no-print w-full md:w-[350px] lg:w-[440px] xl:w-[480px] shrink-0 md:h-full md:overflow-hidden ${
                mobilePane === 'form' ? 'block' : 'hidden md:block'
              }`}
            >
              <LetterFormEditor doc={activeDoc} onChange={setActiveDoc} />
            </aside>

            <section
              className={`flex-1 min-h-0 md:h-full md:overflow-hidden ${
                mobilePane === 'preview' ? 'flex flex-col' : 'hidden md:flex md:flex-col'
              }`}
              aria-label="Pratinjau Surat Resmi A4"
            >
              <LetterPreview
                doc={activeDoc}
                onSaveDraft={handleSaveDraft}
                draftSavedJustNow={draftSavedJustNow}
                onPrint={handlePrint}
              />
            </section>
          </div>
        </main>
      )}

      {activeTab === 'analysis' && (
        <main className="flex-1">
          <ReferenceAnalysisView
            onUseReferenceAsTemplate={handleUseReferenceAsTemplate}
          />
        </main>
      )}

      {activeTab === 'templates' && (
        <main className="flex-1">
          <TemplateLibraryView
            savedDrafts={savedDrafts}
            activeDocId={activeDoc.id}
            onLoadDocument={handleLoadDocument}
            onDuplicateAsNew={handleDuplicateAsNew}
            onDeleteDraft={handleDeleteDraft}
            onImportJson={handleImportJson}
          />
        </main>
      )}
    </div>
  );
}
