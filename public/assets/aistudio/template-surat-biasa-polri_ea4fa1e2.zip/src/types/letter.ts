export type KlasifikasiKode = 'B' | 'R' | 'S';

export interface KopSurat {
  instansi: string;
  satuanInduk: string;
  alamat: string;
  tampilkanEmblem: boolean;
}

export interface IdentitasSurat {
  klasifikasiKode: KlasifikasiKode;
  nomorUrut: string;
  bulanRomawi: string;
  kodeKlasifikasi: string;
  tahun: string;
  satkerPenerbit: string;
  klasifikasiLabel: string;
  lampiran: string;
  hal: string;
  tempat: string;
  tanggal: string;
  headerLanjutanJudul: string;
}

export interface TujuanSurat {
  kepada: string;
  tempatTujuan: string;
}

export interface RujukanItem {
  id: string;
  teks: string;
}

export interface SubPoinDirektif {
  id: string;
  teks: string;
}

export interface DirektifPejabat {
  id: string;
  pejabat: string;
  jenis: 'poin' | 'paragraf';
  poin: SubPoinDirektif[];
  paragrafTunggal?: string;
}

export interface PenandaTangan {
  atasNama: string;
  jabatanUtama: string;
  jabatanPenandaTangan: string;
  nama: string;
  pangkat: string;
  nrp: string;
  tampilkanStempel: boolean;
  stempelSatuan: string;
  stempelJabatan: string;
}

export interface TembusanItem {
  id: string;
  teks: string;
}

export interface PageMargins {
  atas: number;
  kanan: number;
  bawah: number;
  kiri: number;
}

export interface LetterDocument {
  id: string;
  title: string;
  category: string;
  updatedAt: string;
  margins?: PageMargins;
  kop: KopSurat;
  identitas: IdentitasSurat;
  tujuan: TujuanSurat;
  rujukan: RujukanItem[];
  latarBelakang: string;
  pembukaDirektif: string;
  direktifList: DirektifPejabat[];
  penutup: string;
  penandaTangan: PenandaTangan;
  tembusan: TembusanItem[];
}

export type ActiveWorkspaceTab = 'editor' | 'analysis' | 'templates';

export interface ReferenceAnatomySection {
  id: string;
  urutan: string;
  bagian: string;
  posisi: string;
  aturanFormat: string;
  contohReferensi: string;
  keterangan: string;
}
