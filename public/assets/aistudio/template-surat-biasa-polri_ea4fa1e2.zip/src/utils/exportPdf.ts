import { jsPDF } from 'jspdf';
import { DEFAULT_MARGINS, formatNomorSurat } from '../data/referenceLetter';
import { LetterDocument } from '../types/letter';
import { TRIBRATA_IMAGE_URL } from '../components/TribrataEmblem';
import {
  getOfficialStampSvgMarkup,
  loadImageAsset,
  rasterizeSvgToPng,
} from './svgRasterizer';

const A4_WIDTH_MM = 210;
const A4_HEIGHT_MM = 297;
const LINE_HEIGHT_MM = 5.3; // ~11pt with 1.38 line height

function drawUnderlinedText(
  pdf: jsPDF,
  text: string,
  x: number,
  y: number,
  align: 'left' | 'center' | 'right' = 'left'
) {
  pdf.text(text, x, y, { align });
  const w = pdf.getTextWidth(text);
  let startX = x;
  if (align === 'center') startX = x - w / 2;
  if (align === 'right') startX = x - w;
  pdf.setLineWidth(0.25);
  pdf.line(startX, y + 0.9, startX + w, y + 0.9);
}

function drawJustifiedLine(
  pdf: jsPDF,
  line: string,
  x: number,
  y: number,
  maxWidth: number,
  isLastLine: boolean
) {
  const trimmed = line.trim();
  if (!trimmed) return;
  if (isLastLine || !trimmed.includes(' ')) {
    pdf.text(trimmed, x, y);
    return;
  }

  const words = trimmed.split(/\s+/);
  if (words.length <= 1) {
    pdf.text(trimmed, x, y);
    return;
  }

  const wordsWidth = words.reduce((sum, w) => sum + pdf.getTextWidth(w), 0);
  const totalGap = maxWidth - wordsWidth;
  // Guard against overly stretched sparse lines
  if (totalGap <= 0 || totalGap > maxWidth * 0.42) {
    pdf.text(trimmed, x, y);
    return;
  }

  const spacePerGap = totalGap / (words.length - 1);
  let cursorX = x;
  words.forEach((word) => {
    pdf.text(word, cursorX, y);
    cursorX += pdf.getTextWidth(word) + spacePerGap;
  });
}

export async function exportLetterToPdf(doc: LetterDocument): Promise<void> {
  const nomorLengkap = formatNomorSurat(doc.identitas);
  const safeFileName = `Surat_${nomorLengkap.replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`;
  const margins = doc.margins ?? DEFAULT_MARGINS;

  const leftMargin = margins.kiri * 10;
  const rightMargin = margins.kanan * 10;
  const topMargin = margins.atas * 10;
  const bottomMargin = margins.bawah * 10;

  const printableWidth = Math.max(80, A4_WIDTH_MM - leftMargin - rightMargin);
  const maxBottomY = A4_HEIGHT_MM - bottomMargin;

  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  pdf.setFont('helvetica', 'normal');
  pdf.setFontSize(11);
  pdf.setTextColor(0, 0, 0);

  let tribrataAsset: { dataUrl: string; width: number; height: number } | null = null;
  if (doc.kop.tampilkanEmblem) {
    try {
      const img = await loadImageAsset(TRIBRATA_IMAGE_URL);
      tribrataAsset = {
        dataUrl: img.dataUrl,
        width: img.width,
        height: img.height,
      };
    } catch {
      tribrataAsset = null;
    }
  }

  let stampDataUrl: string | null = null;
  if (doc.penandaTangan.tampilkanStempel) {
    try {
      const png = await rasterizeSvgToPng(
        getOfficialStampSvgMarkup(
          doc.penandaTangan.stempelSatuan,
          doc.penandaTangan.stempelJabatan
        ),
        280
      );
      stampDataUrl = png.dataUrl;
    } catch {
      stampDataUrl = null;
    }
  }

  let pageNumber = 1;
  let cursorY = topMargin + 4;

  const drawContinuationHeader = (pNum: number): number => {
    pdf.setFontSize(10.5);
    const title = doc.identitas.headerLanjutanJudul;
    const nomorLine = `NOMOR   : ${nomorLengkap.toUpperCase()}`;
    const tglLine = `TANGGAL: ${doc.identitas.tanggal.toUpperCase()}`;

    const blockW = Math.max(
      pdf.getTextWidth(title),
      pdf.getTextWidth(nomorLine),
      pdf.getTextWidth(tglLine)
    );
    const rightEdge = A4_WIDTH_MM - rightMargin;
    const textStartX = rightEdge - blockW;
    const numX = textStartX - 6;

    const headerTopY = topMargin + 3;
    pdf.text(String(pNum), numX, headerTopY, { align: 'right' });
    drawUnderlinedText(pdf, title, textStartX, headerTopY, 'left');
    drawUnderlinedText(pdf, nomorLine, textStartX, headerTopY + 4.8, 'left');
    drawUnderlinedText(pdf, tglLine, textStartX, headerTopY + 9.6, 'left');

    pdf.setFontSize(11);
    return headerTopY + 18;
  };

  const addNewPage = () => {
    pdf.addPage();
    pageNumber += 1;
    cursorY = drawContinuationHeader(pageNumber);
  };

  const ensureLineSpace = (neededHeight = LINE_HEIGHT_MM) => {
    if (cursorY + neededHeight > maxBottomY) {
      addNewPage();
    }
  };

  const renderNumberedJustified = (
    prefix: string,
    prefixX: number,
    textX: number,
    text: string,
    gapAfterMm = 2.5
  ) => {
    const textWidth = Math.max(30, A4_WIDTH_MM - rightMargin - textX);
    const rawParagraphs = text.split('\n');
    let printedPrefix = false;

    rawParagraphs.forEach((para) => {
      const lines: string[] = pdf.splitTextToSize(para, textWidth);
      if (lines.length === 0) lines.push('');

      lines.forEach((line, lIdx) => {
        ensureLineSpace(LINE_HEIGHT_MM);
        if (!printedPrefix && prefix) {
          pdf.text(prefix, prefixX, cursorY);
          printedPrefix = true;
        }
        const isLast = lIdx === lines.length - 1;
        drawJustifiedLine(pdf, line, textX, cursorY, textWidth, isLast);
        cursorY += LINE_HEIGHT_MM;
      });
    });

    cursorY += gapAfterMm;
  };

  // --- PAGE 1: KOP SURAT ---
  const kopBlockWidth = printableWidth * 0.58;
  const kopCenterX = leftMargin + kopBlockWidth / 2;

  if (tribrataAsset) {
    const emblemHeight = 14.5;
    const emblemWidth = emblemHeight * (tribrataAsset.width / tribrataAsset.height);
    pdf.addImage(
      tribrataAsset.dataUrl,
      'PNG',
      kopCenterX - emblemWidth / 2,
      topMargin,
      emblemWidth,
      emblemHeight
    );
    cursorY = topMargin + emblemHeight + 4.5;
  } else {
    cursorY = topMargin + 4;
  }

  pdf.setFontSize(11);
  pdf.text(doc.kop.instansi, kopCenterX, cursorY, { align: 'center' });
  cursorY += 4.6;

  doc.kop.satuanInduk.split('\n').forEach((line) => {
    pdf.text(line, kopCenterX, cursorY, { align: 'center' });
    cursorY += 4.6;
  });

  pdf.setFontSize(10.5);
  drawUnderlinedText(pdf, doc.kop.alamat, kopCenterX, cursorY, 'center');

  // Tanggal left-aligned with Yth. at rightColX
  const rightColX = leftMargin + kopBlockWidth + 5;
  const rightColWidth = Math.max(30, A4_WIDTH_MM - rightMargin - rightColX);
  pdf.setFontSize(11);
  pdf.text(`${doc.identitas.tempat},  ${doc.identitas.tanggal}`, rightColX, cursorY);

  cursorY += 8.5;

  // --- IDENTITAS SURAT & KEPADA (Kepada aligned with LAST line of Hal) ---
  const idColonX = leftMargin + 23;
  const idValX = leftMargin + 26.5;
  const idValWidth = kopBlockWidth - 26.5;

  const idRows: [string, string][] = [
    ['Nomor', nomorLengkap],
    ['Klasifikasi', doc.identitas.klasifikasiLabel],
    ['Lampiran', doc.identitas.lampiran],
    ['Hal', doc.identitas.hal],
  ];

  let lastHalY = cursorY;
  idRows.forEach(([label, val]) => {
    pdf.text(label, leftMargin, cursorY);
    pdf.text(':', idColonX, cursorY);
    const wrapped: string[] = pdf.splitTextToSize(val, Math.max(25, idValWidth));
    wrapped.forEach((wLine, wIdx) => {
      pdf.text(wLine, idValX, cursorY);
      lastHalY = cursorY;
      if (wIdx < wrapped.length - 1) {
        cursorY += 4.8;
      }
    });
    cursorY += 4.8;
  });

  // Right column: Kepada aligned with DISTRIBUSI (ythValX), Yth. aligned with Semarang (rightColX)
  const ythValX = rightColX + 9.5;
  pdf.text('Kepada', ythValX, lastHalY);

  let rightY = lastHalY + 7.5;
  pdf.text('Yth.', rightColX, rightY);
  const ythValWidth = Math.max(25, A4_WIDTH_MM - rightMargin - ythValX);
  doc.tujuan.kepada.split('\n').forEach((line) => {
    const wrapped: string[] = pdf.splitTextToSize(line, ythValWidth);
    wrapped.forEach((wl) => {
      pdf.text(wl, ythValX, rightY);
      rightY += 4.8;
    });
  });

  rightY += 3;
  pdf.text('di', ythValX, rightY);
  rightY += 7;
  pdf.text(doc.tujuan.tempatTujuan, ythValX, rightY);

  cursorY = Math.max(cursorY, rightY) + 8;

  // --- BODY ---
  // 1. Rujukan
  if (doc.rujukan.length > 0) {
    ensureLineSpace(LINE_HEIGHT_MM);
    pdf.text('1.', leftMargin, cursorY);
    pdf.text('Rujukan:', leftMargin + 8.5, cursorY);
    cursorY += LINE_HEIGHT_MM + 1.5;

    doc.rujukan.forEach((r, idx) => {
      const letter = String.fromCharCode(97 + idx);
      const gap = idx === doc.rujukan.length - 1 ? 3 : 1.5;
      renderNumberedJustified(`${letter}.`, leftMargin + 8.5, leftMargin + 16, r.teks, gap);
    });
  }

  // 2. Latar Belakang
  renderNumberedJustified('2.', leftMargin, leftMargin + 8.5, doc.latarBelakang, 3);

  // 3. Pembuka Direktif
  renderNumberedJustified('3.', leftMargin, leftMargin + 8.5, doc.pembukaDirektif, 2.5);

  // a. - q. Direktif
  doc.direktifList.forEach((dir, dIdx) => {
    const letter = String.fromCharCode(97 + dIdx);
    cursorY += 1.5;

    if (dir.jenis === 'paragraf') {
      renderNumberedJustified(
        `${letter}.`,
        leftMargin + 8.5,
        leftMargin + 16,
        dir.pejabat,
        2.5
      );
    } else {
      // Keep header with at least 1 line of first sub-point
      const headerWidth = Math.max(30, A4_WIDTH_MM - rightMargin - (leftMargin + 16));
      const headerLines: string[] = pdf.splitTextToSize(dir.pejabat, headerWidth);
      const headerHeight = headerLines.length * LINE_HEIGHT_MM;
      if (cursorY + headerHeight + LINE_HEIGHT_MM > maxBottomY) {
        addNewPage();
      }
      renderNumberedJustified(
        `${letter}.`,
        leftMargin + 8.5,
        leftMargin + 16,
        dir.pejabat,
        1.2
      );

      dir.poin.forEach((sub, sIdx) => {
        renderNumberedJustified(
          `${sIdx + 1})`,
          leftMargin + 16,
          leftMargin + 23.5,
          sub.teks,
          1.5
        );
      });
    }
  });

  // 4. Penutup
  cursorY += 1.5;
  renderNumberedJustified('4.', leftMargin, leftMargin + 8.5, doc.penutup, 6);

  // --- TANDA TANGAN & TEMBUSAN ---
  const atasNamaPrefix = doc.penandaTangan.atasNama.trim()
    ? `${doc.penandaTangan.atasNama.trim()} `
    : '';
  const jabatanUtamaFull = `${atasNamaPrefix}${doc.penandaTangan.jabatanUtama}`;
  const pangkatNrpFull = `${doc.penandaTangan.pangkat} ${doc.penandaTangan.nrp}`.trim();

  const sigBlockWidth = Math.max(
    printableWidth * 0.54,
    pdf.getTextWidth(jabatanUtamaFull) + 2,
    pdf.getTextWidth(doc.penandaTangan.nama) + 4,
    pdf.getTextWidth(pangkatNrpFull) + 2
  );
  const sigCenterX = A4_WIDTH_MM - rightMargin - Math.min(printableWidth, sigBlockWidth) / 2;

  const tembusanHeight = doc.tembusan.length > 0 ? 6 + doc.tembusan.length * 4.8 : 0;
  const signatureHeight = 38 + tembusanHeight;

  if (cursorY + signatureHeight > maxBottomY) {
    addNewPage();
  }

  const sigStartY = cursorY + 2;
  pdf.text(jabatanUtamaFull, sigCenterX, sigStartY, { align: 'center' });
  pdf.text(doc.penandaTangan.jabatanPenandaTangan, sigCenterX, sigStartY + 4.8, {
    align: 'center',
  });

  if (stampDataUrl) {
    const stampSize = 26;
    pdf.addImage(
      stampDataUrl,
      'PNG',
      sigCenterX - stampSize / 2,
      sigStartY + 4,
      stampSize,
      stampSize
    );
  }

  const nameY = sigStartY + 27;
  pdf.text(doc.penandaTangan.nama, sigCenterX, nameY, { align: 'center' });
  const underlineWidth = pangkatNrpFull
    ? pdf.getTextWidth(pangkatNrpFull)
    : pdf.getTextWidth(doc.penandaTangan.nama);
  pdf.setLineWidth(0.25);
  pdf.line(
    sigCenterX - underlineWidth / 2,
    nameY + 0.9,
    sigCenterX + underlineWidth / 2,
    nameY + 0.9
  );
  pdf.text(pangkatNrpFull, sigCenterX, nameY + 4.8, { align: 'center' });

  if (doc.tembusan.length > 0) {
    let temY = nameY + 11;
    if (temY + doc.tembusan.length * 4.8 > maxBottomY) {
      addNewPage();
      temY = cursorY;
    }
    pdf.text('Tembusan:', leftMargin, temY);
    temY += 5;
    doc.tembusan.forEach((t, idx) => {
      pdf.text(`${idx + 1}.`, leftMargin, temY);
      const tWrapped: string[] = pdf.splitTextToSize(
        t.teks,
        Math.max(40, sigCenterX - sigBlockWidth / 2 - leftMargin - 8)
      );
      tWrapped.forEach((tl) => {
        pdf.text(tl, leftMargin + 6.5, temY);
        temY += 4.6;
      });
    });
  }

  void rightColWidth;
  pdf.save(safeFileName);
}
