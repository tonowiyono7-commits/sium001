import { DEFAULT_MARGINS, formatNomorSurat } from '../data/referenceLetter';
import { LetterDocument } from '../types/letter';

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br/>');
}

function letterIndex(idx: number): string {
  return String.fromCharCode(97 + idx); // a, b, c...
}

export function exportLetterToWordDoc(doc: LetterDocument): void {
  const nomorLengkap = formatNomorSurat(doc.identitas);
  const safeFileName = `Surat_${nomorLengkap.replace(/[^a-zA-Z0-9_-]/g, '_')}.doc`;
  const margins = doc.margins ?? DEFAULT_MARGINS;

  const rujukanHtml = doc.rujukan
    .map(
      (item, i) => `
      <tr>
        <td style="width:24pt;vertical-align:top;padding-bottom:4pt;">${letterIndex(i)}.</td>
        <td style="vertical-align:top;text-align:justify;padding-bottom:4pt;">${escapeHtml(item.teks)}</td>
      </tr>`
    )
    .join('');

  const direktifHtml = doc.direktifList
    .map((dir, i) => {
      if (dir.jenis === 'paragraf') {
        return `
        <tr>
          <td style="width:24pt;vertical-align:top;padding-bottom:8pt;">${letterIndex(i)}.</td>
          <td style="vertical-align:top;text-align:justify;padding-bottom:8pt;">${escapeHtml(dir.pejabat)}</td>
        </tr>`;
      }

      const subPoinRows = dir.poin
        .map(
          (sub, j) => `
          <tr>
            <td style="width:24pt;vertical-align:top;padding-bottom:4pt;">${j + 1})</td>
            <td style="vertical-align:top;text-align:justify;padding-bottom:4pt;">${escapeHtml(sub.teks)}</td>
          </tr>`
        )
        .join('');

      return `
      <tr>
        <td style="width:24pt;vertical-align:top;padding-bottom:6pt;">${letterIndex(i)}.</td>
        <td style="vertical-align:top;padding-bottom:6pt;">
          <div style="margin-bottom:4pt;">${escapeHtml(dir.pejabat)}</div>
          <table style="width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:11pt;line-height:1.35;">
            ${subPoinRows}
          </table>
        </td>
      </tr>`;
    })
    .join('');

  const tembusanHtml = doc.tembusan
    .map(
      (item, i) => `
      <tr>
        <td style="width:18pt;vertical-align:top;">${i + 1}.</td>
        <td style="vertical-align:top;">${escapeHtml(item.teks)}</td>
      </tr>`
    )
    .join('');

  const atasNamaPrefix = doc.penandaTangan.atasNama.trim()
    ? `${escapeHtml(doc.penandaTangan.atasNama.trim())} `
    : '';

  const htmlContent = `
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:w="urn:schemas-microsoft-com:office:word"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(nomorLengkap)}</title>
  <!--[if gte mso 9]>
  <xml>
    <w:WordDocument>
      <w:View>Print</w:View>
      <w:Zoom>100</w:Zoom>
      <w:DoNotOptimizeForBrowser/>
    </w:WordDocument>
  </xml>
  <![endif]-->
  <style>
    @page {
      size: 210mm 297mm;
      margin: ${margins.atas}cm ${margins.kanan}cm ${margins.bawah}cm ${margins.kiri}cm;
    }
    body {
      font-family: Arial, Helvetica, sans-serif;
      font-size: 11pt;
      line-height: 1.35;
      color: #000000;
    }
    p { margin: 0 0 6pt 0; }
    table { border-collapse: collapse; }
    td { font-family: Arial, Helvetica, sans-serif; font-size: 11pt; line-height: 1.35; }
  </style>
</head>
<body>
  <!-- Kop Surat -->
  <table style="width:100%;margin-bottom:14pt;">
    <tr>
      <td style="width:58%;text-align:center;vertical-align:top;">
        <div style="font-size:11pt;line-height:1.25;">${escapeHtml(doc.kop.instansi)}</div>
        <div style="font-size:11pt;line-height:1.25;">${escapeHtml(doc.kop.satuanInduk)}</div>
        <div style="font-size:10.5pt;line-height:1.25;border-bottom:1pt solid #000000;padding-bottom:3pt;display:inline-block;">
          ${escapeHtml(doc.kop.alamat)}
        </div>
      </td>
      <td style="width:42%;vertical-align:bottom;text-align:right;font-size:11pt;">
        ${escapeHtml(doc.identitas.tempat)}, &nbsp; ${escapeHtml(doc.identitas.tanggal)}
      </td>
    </tr>
  </table>

  <!-- Identitas Surat & Tujuan -->
  <table style="width:100%;margin-bottom:16pt;">
    <tr>
      <td style="width:58%;vertical-align:top;">
        <table style="width:100%;">
          <tr>
            <td style="width:70pt;vertical-align:top;">Nomor</td>
            <td style="width:10pt;vertical-align:top;">:</td>
            <td style="vertical-align:top;">${escapeHtml(nomorLengkap)}</td>
          </tr>
          <tr>
            <td style="vertical-align:top;">Klasifikasi</td>
            <td style="vertical-align:top;">:</td>
            <td style="vertical-align:top;">${escapeHtml(doc.identitas.klasifikasiLabel)}</td>
          </tr>
          <tr>
            <td style="vertical-align:top;">Lampiran</td>
            <td style="vertical-align:top;">:</td>
            <td style="vertical-align:top;">${escapeHtml(doc.identitas.lampiran)}</td>
          </tr>
          <tr>
            <td style="vertical-align:top;">Hal</td>
            <td style="vertical-align:top;">:</td>
            <td style="vertical-align:top;">${escapeHtml(doc.identitas.hal)}</td>
          </tr>
        </table>
      </td>
      <td style="width:42%;vertical-align:bottom;padding-left:20pt;">
        <div>Kepada</div>
      </td>
    </tr>
    <tr>
      <td style="width:58%;"></td>
      <td style="width:42%;vertical-align:top;padding-left:20pt;padding-top:6pt;">
        <table style="width:100%;">
          <tr>
            <td style="width:28pt;vertical-align:top;">Yth.</td>
            <td style="vertical-align:top;">${escapeHtml(doc.tujuan.kepada)}</td>
          </tr>
          <tr>
            <td></td>
            <td style="padding-top:6pt;">di</td>
          </tr>
          <tr>
            <td></td>
            <td style="padding-top:6pt;">${escapeHtml(doc.tujuan.tempatTujuan)}</td>
          </tr>
        </table>
      </td>
    </tr>
  </table>

  <!-- Batang Tubuh -->
  <table style="width:100%;margin-bottom:12pt;">
    <tr>
      <td style="width:24pt;vertical-align:top;padding-bottom:6pt;">1.</td>
      <td style="vertical-align:top;padding-bottom:6pt;">
        <div style="margin-bottom:6pt;">Rujukan:</div>
        <table style="width:100%;">${rujukanHtml}</table>
      </td>
    </tr>
    <tr>
      <td style="width:24pt;vertical-align:top;padding-bottom:8pt;">2.</td>
      <td style="vertical-align:top;text-align:justify;padding-bottom:8pt;">${escapeHtml(doc.latarBelakang)}</td>
    </tr>
    <tr>
      <td style="width:24pt;vertical-align:top;padding-bottom:6pt;">3.</td>
      <td style="vertical-align:top;padding-bottom:6pt;">
        <div style="text-align:justify;margin-bottom:8pt;">${escapeHtml(doc.pembukaDirektif)}</div>
        <table style="width:100%;">${direktifHtml}</table>
      </td>
    </tr>
    <tr>
      <td style="width:24pt;vertical-align:top;padding-bottom:14pt;">4.</td>
      <td style="vertical-align:top;text-align:justify;padding-bottom:14pt;">${escapeHtml(doc.penutup)}</td>
    </tr>
  </table>

  <!-- Penutup Tanda Tangan & Tembusan -->
  <table style="width:100%;margin-top:12pt;">
    <tr>
      <td style="width:38%;vertical-align:bottom;">
        ${
          doc.tembusan.length > 0
            ? `<div style="margin-bottom:4pt;">Tembusan:</div>
               <table style="width:100%;">${tembusanHtml}</table>`
            : ''
        }
      </td>
      <td style="width:62%;vertical-align:top;text-align:center;">
        <div style="white-space:nowrap;">${atasNamaPrefix}${escapeHtml(doc.penandaTangan.jabatanUtama)}</div>
        <div>${escapeHtml(doc.penandaTangan.jabatanPenandaTangan)}</div>
        <div style="height:54pt;">&nbsp;</div>
        <div style="text-decoration:underline;">${escapeHtml(doc.penandaTangan.nama)}</div>
        <div>${escapeHtml(doc.penandaTangan.pangkat)} ${escapeHtml(doc.penandaTangan.nrp)}</div>
      </td>
    </tr>
  </table>
</body>
</html>`;

  const blob = new Blob(['\ufeff', htmlContent], {
    type: 'application/msword;charset=utf-8',
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeFileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function letterToPlainText(doc: LetterDocument): string {
  const nomorLengkap = formatNomorSurat(doc.identitas);
  const lines: string[] = [];

  lines.push(doc.kop.instansi);
  lines.push(doc.kop.satuanInduk);
  lines.push(doc.kop.alamat);
  lines.push('');
  lines.push(`${doc.identitas.tempat}, ${doc.identitas.tanggal}`);
  lines.push(`Nomor      : ${nomorLengkap}`);
  lines.push(`Klasifikasi: ${doc.identitas.klasifikasiLabel}`);
  lines.push(`Lampiran   : ${doc.identitas.lampiran}`);
  lines.push(`Hal        : ${doc.identitas.hal}`);
  lines.push('');
  lines.push('Kepada');
  lines.push(`Yth. ${doc.tujuan.kepada}`);
  lines.push('di');
  lines.push(doc.tujuan.tempatTujuan);
  lines.push('');
  lines.push('1. Rujukan:');
  doc.rujukan.forEach((r, i) => {
    lines.push(`   ${letterIndex(i)}. ${r.teks}`);
  });
  lines.push('');
  lines.push(`2. ${doc.latarBelakang}`);
  lines.push('');
  lines.push(`3. ${doc.pembukaDirektif}`);
  doc.direktifList.forEach((d, i) => {
    lines.push(`   ${letterIndex(i)}. ${d.pejabat}`);
    if (d.jenis === 'poin') {
      d.poin.forEach((p, j) => {
        lines.push(`      ${j + 1}) ${p.teks}`);
      });
    }
  });
  lines.push('');
  lines.push(`4. ${doc.penutup}`);
  lines.push('');
  const anPrefix = doc.penandaTangan.atasNama.trim() ? `${doc.penandaTangan.atasNama.trim()} ` : '';
  lines.push(`${anPrefix}${doc.penandaTangan.jabatanUtama}`);
  lines.push(doc.penandaTangan.jabatanPenandaTangan);
  lines.push('');
  lines.push(doc.penandaTangan.nama);
  lines.push(`${doc.penandaTangan.pangkat} ${doc.penandaTangan.nrp}`);
  if (doc.tembusan.length > 0) {
    lines.push('');
    lines.push('Tembusan:');
    doc.tembusan.forEach((t, i) => {
      lines.push(`${i + 1}. ${t.teks}`);
    });
  }

  return lines.join('\n');
}
