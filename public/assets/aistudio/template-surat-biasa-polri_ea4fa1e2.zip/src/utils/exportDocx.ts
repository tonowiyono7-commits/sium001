import {
  AlignmentType,
  BorderStyle,
  convertMillimetersToTwip,
  Document,
  Header,
  ImageRun,
  Packer,
  PageNumber,
  PageOrientation,
  Paragraph,
  Table,
  TableCell,
  TableLayoutType,
  TableRow,
  TextRun,
  UnderlineType,
  VerticalAlign,
  WidthType,
} from 'docx';
import { DEFAULT_MARGINS, formatNomorSurat } from '../data/referenceLetter';
import { LetterDocument } from '../types/letter';
import { TRIBRATA_IMAGE_URL } from '../components/TribrataEmblem';
import {
  getOfficialStampSvgMarkup,
  loadImageAsset,
  rasterizeSvgToPng,
} from './svgRasterizer';

const FONT_NAME = 'Arial';
const BODY_SIZE_HP = 22; // 11pt
const SMALL_SIZE_HP = 21; // 10.5pt

const NO_BORDER = {
  style: BorderStyle.NONE,
  size: 0,
  color: 'FFFFFF',
};

const NO_CELL_BORDERS = {
  top: NO_BORDER,
  bottom: NO_BORDER,
  left: NO_BORDER,
  right: NO_BORDER,
};

const NO_TABLE_BORDERS = {
  top: NO_BORDER,
  bottom: NO_BORDER,
  left: NO_BORDER,
  right: NO_BORDER,
  insideHorizontal: NO_BORDER,
  insideVertical: NO_BORDER,
};

function makeRun(
  text: string,
  options?: { size?: number; underline?: boolean; bold?: boolean }
): TextRun {
  return new TextRun({
    text,
    font: FONT_NAME,
    size: options?.size ?? BODY_SIZE_HP,
    bold: options?.bold ?? false,
    underline: options?.underline ? { type: UnderlineType.SINGLE } : undefined,
  });
}

function makeMultilineRuns(text: string, size = BODY_SIZE_HP): TextRun[] {
  const lines = text.split('\n');
  const runs: TextRun[] = [];
  lines.forEach((line, idx) => {
    if (idx > 0) {
      runs.push(new TextRun({ break: 1, font: FONT_NAME, size }));
    }
    runs.push(makeRun(line, { size }));
  });
  return runs;
}

function measureArial11PtTwips(text: string): number {
  if (!text) return 0;
  if (typeof document !== 'undefined') {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.font = '11pt Arial';
      const px = ctx.measureText(text).width;
      // 1 CSS px at 96 DPI = 15 twips
      return Math.ceil(px * 15) + 40;
    }
  }
  return text.length * 125;
}

export async function exportLetterToDocx(doc: LetterDocument): Promise<void> {
  const nomorLengkap = formatNomorSurat(doc.identitas);
  const safeFileName = `Surat_${nomorLengkap.replace(/[^a-zA-Z0-9_-]/g, '_')}.docx`;
  const margins = doc.margins ?? DEFAULT_MARGINS;

  const printableWidthMm = Math.max(80, 210 - (margins.kiri + margins.kanan) * 10);
  const totalWidthTwips = convertMillimetersToTwip(printableWidthMm);

  let tribrataAsset: { bytes: Uint8Array; width: number; height: number } | null = null;
  if (doc.kop.tampilkanEmblem) {
    try {
      const img = await loadImageAsset(TRIBRATA_IMAGE_URL);
      tribrataAsset = {
        bytes: img.bytes,
        width: img.width,
        height: img.height,
      };
    } catch {
      tribrataAsset = null;
    }
  }

  let stampBytes: Uint8Array | null = null;
  if (doc.penandaTangan.tampilkanStempel) {
    try {
      const png = await rasterizeSvgToPng(
        getOfficialStampSvgMarkup(
          doc.penandaTangan.stempelSatuan,
          doc.penandaTangan.stempelJabatan
        ),
        260
      );
      stampBytes = png.bytes;
    } catch {
      stampBytes = null;
    }
  }

  // Continuation header for pages 2+
  const hdrCol1 = Math.round(totalWidthTwips * 0.44);
  const hdrCol2 = Math.round(totalWidthTwips * 0.06);
  const hdrCol3 = totalWidthTwips - hdrCol1 - hdrCol2;

  const continuationHeader = new Header({
    children: [
      new Table({
        width: { size: totalWidthTwips, type: WidthType.DXA },
        columnWidths: [hdrCol1, hdrCol2, hdrCol3],
        layout: TableLayoutType.FIXED,
        borders: NO_TABLE_BORDERS,
        rows: [
          new TableRow({
            children: [
              new TableCell({
                width: { size: hdrCol1, type: WidthType.DXA },
                borders: NO_CELL_BORDERS,
                children: [new Paragraph({ children: [] })],
              }),
              new TableCell({
                width: { size: hdrCol2, type: WidthType.DXA },
                borders: NO_CELL_BORDERS,
                verticalAlign: VerticalAlign.TOP,
                children: [
                  new Paragraph({
                    alignment: AlignmentType.RIGHT,
                    children: [
                      new TextRun({
                        children: [PageNumber.CURRENT],
                        font: FONT_NAME,
                        size: SMALL_SIZE_HP,
                      }),
                    ],
                  }),
                ],
              }),
              new TableCell({
                width: { size: hdrCol3, type: WidthType.DXA },
                borders: NO_CELL_BORDERS,
                margins: { left: convertMillimetersToTwip(3), right: 0, top: 0, bottom: 0 },
                children: [
                  new Paragraph({
                    spacing: { after: 0, line: 260 },
                    children: [
                      makeRun(doc.identitas.headerLanjutanJudul, {
                        size: SMALL_SIZE_HP,
                        underline: true,
                      }),
                    ],
                  }),
                  new Paragraph({
                    spacing: { after: 0, line: 260 },
                    children: [
                      makeRun(`NOMOR   : ${nomorLengkap.toUpperCase()}`, {
                        size: SMALL_SIZE_HP,
                        underline: true,
                      }),
                    ],
                  }),
                  new Paragraph({
                    spacing: { after: 140, line: 260 },
                    children: [
                      makeRun(`TANGGAL: ${doc.identitas.tanggal.toUpperCase()}`, {
                        size: SMALL_SIZE_HP,
                        underline: true,
                      }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  // Kop Surat Table
  const kopLeftWidth = Math.round(totalWidthTwips * 0.58);
  const kopRightWidth = totalWidthTwips - kopLeftWidth;

  const kopChildren: Paragraph[] = [];
  if (tribrataAsset) {
    const heightPx = 52;
    const widthPx = Math.round(heightPx * (tribrataAsset.width / tribrataAsset.height));
    kopChildren.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 60 },
        children: [
          new ImageRun({
            type: 'png',
            data: tribrataAsset.bytes,
            transformation: { width: widthPx, height: heightPx },
          }),
        ],
      })
    );
  }
  kopChildren.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 0, line: 250 },
      children: [makeRun(doc.kop.instansi)],
    })
  );
  kopChildren.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 0, line: 250 },
      children: makeMultilineRuns(doc.kop.satuanInduk),
    })
  );
  kopChildren.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 0, line: 250 },
      border: {
        bottom: { style: BorderStyle.SINGLE, size: 6, color: '000000', space: 2 },
      },
      children: [makeRun(doc.kop.alamat, { size: SMALL_SIZE_HP })],
    })
  );

  const kopTable = new Table({
    width: { size: totalWidthTwips, type: WidthType.DXA },
    columnWidths: [kopLeftWidth, kopRightWidth],
    layout: TableLayoutType.FIXED,
    borders: NO_TABLE_BORDERS,
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: kopLeftWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            verticalAlign: VerticalAlign.BOTTOM,
            children: kopChildren,
          }),
          new TableCell({
            width: { size: kopRightWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: convertMillimetersToTwip(6), right: 0 },
            verticalAlign: VerticalAlign.BOTTOM,
            children: [
              new Paragraph({
                alignment: AlignmentType.LEFT,
                spacing: { after: 0 },
                children: [
                  makeRun(`${doc.identitas.tempat},  ${doc.identitas.tanggal}`),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  // Identitas Surat & Kepada aligned with last line of Hal
  const idLabelW = convertMillimetersToTwip(24);
  const idColonW = convertMillimetersToTwip(4);
  const idValW = Math.max(1000, kopLeftWidth - idLabelW - idColonW);

  const makeIdRow = (label: string, value: string) =>
    new TableRow({
      children: [
        new TableCell({
          width: { size: idLabelW, type: WidthType.DXA },
          borders: NO_CELL_BORDERS,
          margins: { top: 0, bottom: 0, left: 0, right: 0 },
          children: [new Paragraph({ spacing: { after: 20 }, children: [makeRun(label)] })],
        }),
        new TableCell({
          width: { size: idColonW, type: WidthType.DXA },
          borders: NO_CELL_BORDERS,
          margins: { top: 0, bottom: 0, left: 0, right: 0 },
          children: [new Paragraph({ spacing: { after: 20 }, children: [makeRun(':')] })],
        }),
        new TableCell({
          width: { size: idValW, type: WidthType.DXA },
          borders: NO_CELL_BORDERS,
          margins: { top: 0, bottom: 0, left: 0, right: 0 },
          children: [
            new Paragraph({
              spacing: { after: 20 },
              children: makeMultilineRuns(value),
            }),
          ],
        }),
      ],
    });

  const identitasSubTable = new Table({
    width: { size: kopLeftWidth, type: WidthType.DXA },
    columnWidths: [idLabelW, idColonW, idValW],
    layout: TableLayoutType.FIXED,
    borders: NO_TABLE_BORDERS,
    rows: [
      makeIdRow('Nomor', nomorLengkap),
      makeIdRow('Klasifikasi', doc.identitas.klasifikasiLabel),
      makeIdRow('Lampiran', doc.identitas.lampiran),
      makeIdRow('Hal', doc.identitas.hal),
    ],
  });

  const tujuanBoxWidth = kopRightWidth - convertMillimetersToTwip(6);
  const ythLabelW = convertMillimetersToTwip(11);
  const ythValW = Math.max(1000, tujuanBoxWidth - ythLabelW);

  const tujuanSubTable = new Table({
    width: { size: tujuanBoxWidth, type: WidthType.DXA },
    columnWidths: [ythLabelW, ythValW],
    layout: TableLayoutType.FIXED,
    borders: NO_TABLE_BORDERS,
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: ythLabelW, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [new Paragraph({ spacing: { after: 40 }, children: [makeRun('Yth.')] })],
          }),
          new TableCell({
            width: { size: ythValW, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [
              new Paragraph({
                spacing: { after: 40 },
                children: makeMultilineRuns(doc.tujuan.kepada),
              }),
            ],
          }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            width: { size: ythLabelW, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [new Paragraph({ children: [] })],
          }),
          new TableCell({
            width: { size: ythValW, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [
              new Paragraph({
                spacing: { before: 80, after: 80 },
                children: [makeRun('di')],
              }),
              new Paragraph({
                spacing: { after: 0 },
                children: [makeRun(doc.tujuan.tempatTujuan)],
              }),
            ],
          }),
        ],
      }),
    ],
  });

  const metaAndTujuanTable = new Table({
    width: { size: totalWidthTwips, type: WidthType.DXA },
    columnWidths: [kopLeftWidth, kopRightWidth],
    layout: TableLayoutType.FIXED,
    borders: NO_TABLE_BORDERS,
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: kopLeftWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            verticalAlign: VerticalAlign.TOP,
            children: [identitasSubTable],
          }),
          new TableCell({
            width: { size: kopRightWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            verticalAlign: VerticalAlign.BOTTOM,
            margins: { left: convertMillimetersToTwip(6), right: 0, top: 0, bottom: 0 },
            children: [
              new Paragraph({
                indent: { left: ythLabelW },
                spacing: { after: 20 },
                children: [makeRun('Kepada')],
              }),
            ],
          }),
        ],
      }),
      new TableRow({
        children: [
          new TableCell({
            width: { size: kopLeftWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [new Paragraph({ children: [] })],
          }),
          new TableCell({
            width: { size: kopRightWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            verticalAlign: VerticalAlign.TOP,
            margins: { left: convertMillimetersToTwip(6), top: convertMillimetersToTwip(2), right: 0, bottom: 0 },
            children: [tujuanSubTable],
          }),
        ],
      }),
    ],
  });

  // Body Paragraphs with hanging indents matching official layout
  const bodyChildren: (Paragraph | Table)[] = [
    kopTable,
    new Paragraph({ spacing: { after: 180 }, children: [] }),
    metaAndTujuanTable,
    new Paragraph({ spacing: { after: 220 }, children: [] }),
  ];

  // 1. Rujukan
  if (doc.rujukan.length > 0) {
    bodyChildren.push(
      new Paragraph({
        indent: { left: convertMillimetersToTwip(8.5), hanging: convertMillimetersToTwip(8.5) },
        spacing: { after: 80, line: 290 },
        children: [makeRun('1.\tRujukan:')],
      })
    );
    doc.rujukan.forEach((r, idx) => {
      const letter = String.fromCharCode(97 + idx);
      bodyChildren.push(
        new Paragraph({
          alignment: AlignmentType.JUSTIFIED,
          indent: { left: convertMillimetersToTwip(16), hanging: convertMillimetersToTwip(7.5) },
          spacing: {
            after: idx === doc.rujukan.length - 1 ? 140 : 80,
            line: 290,
          },
          children: [makeRun(`${letter}.\t`), ...makeMultilineRuns(r.teks)],
        })
      );
    });
  }

  // 2. Latar Belakang
  bodyChildren.push(
    new Paragraph({
      alignment: AlignmentType.JUSTIFIED,
      indent: { left: convertMillimetersToTwip(8.5), hanging: convertMillimetersToTwip(8.5) },
      spacing: { after: 140, line: 290 },
      children: [makeRun('2.\t'), ...makeMultilineRuns(doc.latarBelakang)],
    })
  );

  // 3. Pembuka Direktif
  bodyChildren.push(
    new Paragraph({
      alignment: AlignmentType.JUSTIFIED,
      indent: { left: convertMillimetersToTwip(8.5), hanging: convertMillimetersToTwip(8.5) },
      spacing: { after: 120, line: 290 },
      children: [makeRun('3.\t'), ...makeMultilineRuns(doc.pembukaDirektif)],
    })
  );

  // a. - q. Direktif
  doc.direktifList.forEach((dir, dIdx) => {
    const letter = String.fromCharCode(97 + dIdx);
    if (dir.jenis === 'paragraf') {
      bodyChildren.push(
        new Paragraph({
          alignment: AlignmentType.JUSTIFIED,
          indent: { left: convertMillimetersToTwip(16), hanging: convertMillimetersToTwip(7.5) },
          spacing: { before: 80, after: 100, line: 290 },
          children: [makeRun(`${letter}.\t`), ...makeMultilineRuns(dir.pejabat)],
        })
      );
    } else {
      bodyChildren.push(
        new Paragraph({
          indent: { left: convertMillimetersToTwip(16), hanging: convertMillimetersToTwip(7.5) },
          spacing: { before: 80, after: 60, line: 290 },
          keepNext: true,
          children: [makeRun(`${letter}.\t`), ...makeMultilineRuns(dir.pejabat)],
        })
      );

      dir.poin.forEach((sub, sIdx) => {
        bodyChildren.push(
          new Paragraph({
            alignment: AlignmentType.JUSTIFIED,
            indent: { left: convertMillimetersToTwip(23.5), hanging: convertMillimetersToTwip(7.5) },
            spacing: { after: 60, line: 290 },
            children: [makeRun(`${sIdx + 1})\t`), ...makeMultilineRuns(sub.teks)],
          })
        );
      });
    }
  });

  // 4. Penutup
  bodyChildren.push(
    new Paragraph({
      alignment: AlignmentType.JUSTIFIED,
      indent: { left: convertMillimetersToTwip(8.5), hanging: convertMillimetersToTwip(8.5) },
      spacing: { before: 120, after: 200, line: 290 },
      children: [makeRun('4.\t'), ...makeMultilineRuns(doc.penutup)],
    })
  );

  // Signature & Tembusan Table (62% right column keeps Jabatan Pimpinan Utama single-line)
  const tembusanWidth = Math.round(totalWidthTwips * 0.36);
  const ttdWidth = totalWidthTwips - tembusanWidth;

  const tembusanParagraphs: Paragraph[] =
    doc.tembusan.length > 0
      ? [
          new Paragraph({
            spacing: { after: 40 },
            children: [makeRun('Tembusan:')],
          }),
          ...doc.tembusan.map(
            (t, idx) =>
              new Paragraph({
                indent: {
                  left: convertMillimetersToTwip(6),
                  hanging: convertMillimetersToTwip(6),
                },
                spacing: { after: 20 },
                children: [makeRun(`${idx + 1}.\t${t.teks}`)],
              })
          ),
        ]
      : [new Paragraph({ children: [] })];

  const atasNamaPrefix = doc.penandaTangan.atasNama.trim()
    ? `${doc.penandaTangan.atasNama.trim()} `
    : '';

  const ttdParagraphs: Paragraph[] = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 0, line: 270 },
      children: [makeRun(`${atasNamaPrefix}${doc.penandaTangan.jabatanUtama}`)],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: stampBytes ? 20 : 640, line: 270 },
      children: [makeRun(doc.penandaTangan.jabatanPenandaTangan)],
    }),
  ];

  if (stampBytes) {
    ttdParagraphs.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 20, after: 20 },
        children: [
          new ImageRun({
            type: 'png',
            data: stampBytes,
            transformation: { width: 84, height: 84 },
          }),
        ],
      })
    );
  }

  const pangkatNrpText = `${doc.penandaTangan.pangkat} ${doc.penandaTangan.nrp}`.trim();
  const targetUnderlineTwips = measureArial11PtTwips(
    pangkatNrpText || doc.penandaTangan.nama
  );
  const nameSideIndent = Math.max(
    0,
    Math.round((ttdWidth - Math.min(ttdWidth, targetUnderlineTwips)) / 2)
  );

  ttdParagraphs.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      indent: { left: nameSideIndent, right: nameSideIndent },
      border: {
        bottom: { style: BorderStyle.SINGLE, size: 6, color: '000000', space: 1 },
      },
      spacing: { after: 20, line: 270 },
      children: [makeRun(doc.penandaTangan.nama)],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 0, line: 270 },
      children: [makeRun(pangkatNrpText)],
    })
  );

  const footerSignatureTable = new Table({
    width: { size: totalWidthTwips, type: WidthType.DXA },
    columnWidths: [tembusanWidth, ttdWidth],
    layout: TableLayoutType.FIXED,
    borders: NO_TABLE_BORDERS,
    rows: [
      new TableRow({
        cantSplit: true,
        children: [
          new TableCell({
            width: { size: tembusanWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            verticalAlign: VerticalAlign.BOTTOM,
            children: tembusanParagraphs,
          }),
          new TableCell({
            width: { size: ttdWidth, type: WidthType.DXA },
            borders: NO_CELL_BORDERS,
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            verticalAlign: VerticalAlign.TOP,
            children: ttdParagraphs,
          }),
        ],
      }),
    ],
  });

  bodyChildren.push(footerSignatureTable);

  const wordDoc = new Document({
    styles: {
      default: {
        document: {
          run: {
            font: FONT_NAME,
            size: BODY_SIZE_HP,
          },
          paragraph: {
            spacing: {
              before: 0,
              after: 0,
            },
          },
        },
      },
    },
    sections: [
      {
        properties: {
          titlePage: true,
          page: {
            size: {
              width: 11906, // Official OOXML A4 width (210mm)
              height: 16838, // Official OOXML A4 height (297mm)
              orientation: PageOrientation.PORTRAIT,
              code: 9, // Windows DMPAPER_A4 so Microsoft Word recognizes paper size as A4
            },
            margin: {
              top: convertMillimetersToTwip(margins.atas * 10),
              right: convertMillimetersToTwip(margins.kanan * 10),
              bottom: convertMillimetersToTwip(margins.bawah * 10),
              left: convertMillimetersToTwip(margins.kiri * 10),
              header: convertMillimetersToTwip(10),
              footer: convertMillimetersToTwip(10),
            },
          },
        },
        headers: {
          first: new Header({ children: [] }),
          default: continuationHeader,
        },
        children: bodyChildren,
      },
    ],
  });

  const blob = await Packer.toBlob(wordDoc);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = safeFileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
