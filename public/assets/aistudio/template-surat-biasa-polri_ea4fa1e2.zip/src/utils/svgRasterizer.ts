/**
 * Converts our Tribrata and Official Stamp SVGs into crisp high-DPI PNG assets
 * for embedding inside real .docx and .pdf exports.
 */

export async function loadImageAsset(src: string): Promise<{
  dataUrl: string;
  bytes: Uint8Array;
  width: number;
  height: number;
}> {
  const response = await fetch(src);
  if (!response.ok) {
    throw new Error(`Gagal memuat aset gambar: ${src}`);
  }
  const blob = await response.blob();
  const bytes = new Uint8Array(await blob.arrayBuffer());

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error ?? new Error('Gagal membaca gambar'));
    reader.readAsDataURL(blob);
  });

  const dims = await new Promise<{ width: number; height: number }>((resolve) => {
    const img = new Image();
    img.onload = () =>
      resolve({
        width: img.naturalWidth || 200,
        height: img.naturalHeight || 181,
      });
    img.onerror = () => resolve({ width: 200, height: 181 });
    img.src = dataUrl;
  });

  return { dataUrl, bytes, width: dims.width, height: dims.height };
}

function escapeXml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function getOfficialStampSvgMarkup(satuan: string, jabatan: string): string {
  const cleanSatuan = escapeXml(satuan.split('\n')[0].toUpperCase().slice(0, 24));
  const cleanJabatan = escapeXml(jabatan.toUpperCase().slice(0, 16));

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 140 140" width="280" height="280">
    <defs>
      <path id="stampTopArc" d="M 22,70 A 48,48 0 1,1 118,70" />
      <path id="stampBottomArc" d="M 22,74 A 48,48 0 0,0 118,74" />
    </defs>
    <circle cx="70" cy="70" r="64" fill="none" stroke="#1e3a8a" stroke-width="2.4" opacity="0.72" />
    <circle cx="70" cy="70" r="60" fill="none" stroke="#1e3a8a" stroke-width="1.1" opacity="0.72" />
    <circle cx="70" cy="70" r="36" fill="none" stroke="#1e3a8a" stroke-width="1.5" opacity="0.72" />
    <text fill="#1e3a8a" font-size="7.4" font-weight="700" letter-spacing="0.8" opacity="0.78" font-family="Arial, sans-serif">
      <textPath href="#stampTopArc" startOffset="50%" text-anchor="middle">KEPOLISIAN NEGARA REPUBLIK INDONESIA</textPath>
    </text>
    <text fill="#1e3a8a" font-size="7.4" font-weight="700" letter-spacing="0.8" opacity="0.78" font-family="Arial, sans-serif">
      <textPath href="#stampBottomArc" startOffset="50%" text-anchor="middle">${cleanSatuan}</textPath>
    </text>
    <text x="70" y="74" text-anchor="middle" fill="#1e3a8a" font-size="10.5" font-weight="700" letter-spacing="0.5" opacity="0.82" font-family="Arial, sans-serif">${cleanJabatan}</text>
    <path d="M 20 118 C 44 92, 68 62, 108 26 M 62 66 C 72 60, 82 54, 92 64 C 84 74, 72 78, 66 72" fill="none" stroke="#0f172a" stroke-width="2.6" stroke-linecap="round" opacity="0.85" />
  </svg>`;
}

export async function rasterizeSvgToPng(
  svgMarkup: string,
  sizePx = 240
): Promise<{ dataUrl: string; bytes: Uint8Array }> {
  return new Promise((resolve, reject) => {
    const svgBlob = new Blob([svgMarkup], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = sizePx;
        canvas.height = sizePx;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          URL.revokeObjectURL(url);
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.clearRect(0, 0, sizePx, sizePx);
        ctx.drawImage(img, 0, 0, sizePx, sizePx);
        const dataUrl = canvas.toDataURL('image/png');
        canvas.toBlob((blob) => {
          URL.revokeObjectURL(url);
          if (!blob) {
            reject(new Error('Failed to encode PNG'));
            return;
          }
          blob
            .arrayBuffer()
            .then((buf) => resolve({ dataUrl, bytes: new Uint8Array(buf) }))
            .catch(reject);
        }, 'image/png');
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };
    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(err);
    };
    img.src = url;
  });
}
