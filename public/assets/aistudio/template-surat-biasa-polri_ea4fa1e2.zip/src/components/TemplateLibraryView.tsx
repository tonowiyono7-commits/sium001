import React, { useRef, useState } from 'react';
import { Copy, Eye, FileDown, FolderOpen, Plus, Trash2, Upload } from 'lucide-react';
import { formatNomorSurat, PRESET_TEMPLATES } from '../data/referenceLetter';
import { LetterDocument } from '../types/letter';
import { DocumentPreviewModal } from './LetterDocumentPages';

interface TemplateLibraryViewProps {
  savedDrafts: LetterDocument[];
  activeDocId: string;
  onLoadDocument: (doc: LetterDocument) => void;
  onDuplicateAsNew: (doc: LetterDocument) => void;
  onDeleteDraft: (id: string) => void;
  onImportJson: (doc: LetterDocument) => void;
}

export const TemplateLibraryView: React.FC<TemplateLibraryViewProps> = ({
  savedDrafts,
  activeDocId,
  onLoadDocument,
  onDuplicateAsNew,
  onDeleteDraft,
  onImportJson,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [previewDoc, setPreviewDoc] = useState<LetterDocument | null>(null);

  const handleExportJson = (doc: LetterDocument) => {
    const blob = new Blob([JSON.stringify(doc, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${doc.title.replace(/[^a-zA-Z0-9_-]/g, '_')}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as LetterDocument;
      if (parsed && parsed.kop && parsed.identitas && Array.isArray(parsed.direktifList)) {
        onImportJson({
          ...parsed,
          id: `draft-${Date.now()}`,
          updatedAt: new Date().toISOString().slice(0, 10),
        });
      }
    } catch {
      // Ignore malformed JSON files
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-10 space-y-12">
      {/* Header */}
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-8 border-b border-slate-200">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs font-medium text-slate-500">
            Pustaka Template & Manajemen Draf
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 text-balance">
            Pilih Kerangka Surat atau Kelola Draf Tersimpan
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Seluruh template mengikuti tata letak, hierarki penomoran, dan standar tata naskah
            dinas dari dokumen referensi B/14381/XI/OPS.2.1./2026/Roops.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Impor Draf (.json)</span>
          </button>
          <button
            type="button"
            onClick={() => onDuplicateAsNew(PRESET_TEMPLATES[3])}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Buat Surat Baru</span>
          </button>
        </div>
      </section>

      {/* Preset Templates */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            01. Template Referensi & Preset Operasional
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Klik gunakan untuk memuat template ke dalam Editor Surat.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {PRESET_TEMPLATES.map((tpl) => {
            const isCurrent = tpl.id === activeDocId;
            return (
              <div
                key={tpl.id}
                className="p-5 border border-slate-200 rounded-lg bg-white flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>{tpl.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-code tabular-nums">
                      {tpl.direktifList.length} bagian direktif
                    </span>
                    {isCurrent && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-slate-900">Sedang dibuka</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-base font-semibold text-slate-900 leading-snug">
                    {tpl.title}
                  </h3>
                  <p className="text-xs text-slate-600 font-mono-code">
                    {formatNomorSurat(tpl.identitas)}
                  </p>
                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    Hal: {tpl.identitas.hal}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 gap-2">
                  <button
                    type="button"
                    onClick={() => onDuplicateAsNew(tpl)}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Salin</span>
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setPreviewDoc(tpl)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Pratinjau</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onLoadDocument(tpl)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap cursor-pointer"
                    >
                      <FolderOpen className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Gunakan</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Saved Drafts */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            02. Draf Tersimpan di Perangkat Ini ({savedDrafts.length})
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            Draf tersimpan otomatis di browser lokal dan dapat diekspor ke berkas JSON.
          </p>
        </div>

        {savedDrafts.length === 0 ? (
          <div className="p-8 border border-dashed border-slate-300 rounded-lg bg-white text-center space-y-2">
            <p className="text-sm font-medium text-slate-900">
              Belum ada draf surat yang disimpan
            </p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Buka Editor Surat lalu tekan tombol &ldquo;Simpan Draf&rdquo; untuk menyimpan
              salinan surat yang sedang Anda susun.
            </p>
          </div>
        ) : (
          <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700">
                    <th className="py-3 px-4">Nama Draf</th>
                    <th className="py-3 px-4">Nomor Surat</th>
                    <th className="py-3 px-4">Diperbarui</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-xs">
                  {savedDrafts.map((draft) => (
                    <tr key={draft.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-medium text-slate-900">
                        <div>{draft.title}</div>
                        <div className="text-slate-500 font-normal truncate max-w-md mt-0.5">
                          Hal: {draft.identitas.hal}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono-code text-slate-700 whitespace-nowrap">
                        {formatNomorSurat(draft.identitas)}
                      </td>
                      <td className="py-3 px-4 font-mono-code tabular-nums text-slate-500 whitespace-nowrap">
                        {draft.updatedAt}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setPreviewDoc(draft)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 rounded cursor-pointer"
                          >
                            <Eye className="w-3 h-3" aria-hidden="true" />
                            <span>Pratinjau</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onLoadDocument(draft)}
                            className="px-2.5 py-1 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded cursor-pointer"
                          >
                            Buka
                          </button>
                          <button
                            type="button"
                            onClick={() => handleExportJson(draft)}
                            aria-label="Ekspor JSON"
                            className="p-1.5 text-slate-500 hover:text-slate-900 cursor-pointer"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteDraft(draft.id)}
                            aria-label="Hapus draf"
                            className="p-1.5 text-slate-500 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>

      {previewDoc && (
        <DocumentPreviewModal
          doc={previewDoc}
          onClose={() => setPreviewDoc(null)}
          onUseTemplate={(doc) => onLoadDocument(doc)}
        />
      )}
    </div>
  );
};
