import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Plus,
  Trash2,
} from 'lucide-react';
import {
  DEFAULT_MARGINS,
  formatNomorSurat,
  STANDARD_PEJABAT_SUGGESTIONS,
} from '../data/referenceLetter';
import {
  DirektifPejabat,
  KlasifikasiKode,
  LetterDocument,
  PageMargins,
} from '../types/letter';

interface LetterFormEditorProps {
  doc: LetterDocument;
  onChange: (updated: LetterDocument) => void;
}

type EditorSection = 'identitas' | 'rujukan' | 'direktif' | 'penutup';

const MONTHS_ROMAN: { label: string; roman: string }[] = [
  { label: 'Januari', roman: 'I' },
  { label: 'Februari', roman: 'II' },
  { label: 'Maret', roman: 'III' },
  { label: 'April', roman: 'IV' },
  { label: 'Mei', roman: 'V' },
  { label: 'Juni', roman: 'VI' },
  { label: 'Juli', roman: 'VII' },
  { label: 'Agustus', roman: 'VIII' },
  { label: 'September', roman: 'IX' },
  { label: 'Oktober', roman: 'X' },
  { label: 'November', roman: 'XI' },
  { label: 'Desember', roman: 'XII' },
];

export const LetterFormEditor: React.FC<LetterFormEditorProps> = ({ doc, onChange }) => {
  const [section, setSection] = useState<EditorSection>('identitas');
  const [selectedQuickPejabat, setSelectedQuickPejabat] = useState<string>(
    STANDARD_PEJABAT_SUGGESTIONS[0]
  );
  const [expandedDirektifId, setExpandedDirektifId] = useState<string | null>(
    doc.direktifList[0]?.id ?? null
  );

  const updateKop = (patch: Partial<LetterDocument['kop']>) => {
    onChange({ ...doc, kop: { ...doc.kop, ...patch } });
  };

  const updateIdentitas = (patch: Partial<LetterDocument['identitas']>) => {
    onChange({ ...doc, identitas: { ...doc.identitas, ...patch } });
  };

  const updateTujuan = (patch: Partial<LetterDocument['tujuan']>) => {
    onChange({ ...doc, tujuan: { ...doc.tujuan, ...patch } });
  };

  const updatePenandaTangan = (patch: Partial<LetterDocument['penandaTangan']>) => {
    onChange({ ...doc, penandaTangan: { ...doc.penandaTangan, ...patch } });
  };

  const currentMargins: PageMargins = doc.margins ?? DEFAULT_MARGINS;

  const updateMargin = (key: keyof PageMargins, rawValue: string) => {
    const parsed = parseFloat(rawValue);
    if (Number.isNaN(parsed)) return;
    const clamped = Math.min(6, Math.max(0.5, Number(parsed.toFixed(2))));
    onChange({
      ...doc,
      margins: {
        ...currentMargins,
        [key]: clamped,
      },
    });
  };

  const resetMargins = () => {
    onChange({
      ...doc,
      margins: { ...DEFAULT_MARGINS },
    });
  };

  // Rujukan handlers
  const addRujukan = () => {
    const newItem = {
      id: `ruj-${Date.now()}`,
      teks: 'Peraturan atau surat rujukan baru...',
    };
    onChange({ ...doc, rujukan: [...doc.rujukan, newItem] });
  };

  const updateRujukan = (id: string, teks: string) => {
    onChange({
      ...doc,
      rujukan: doc.rujukan.map((r) => (r.id === id ? { ...r, teks } : r)),
    });
  };

  const removeRujukan = (id: string) => {
    onChange({
      ...doc,
      rujukan: doc.rujukan.filter((r) => r.id !== id),
    });
  };

  const moveRujukan = (index: number, direction: -1 | 1) => {
    const next = [...doc.rujukan];
    const target = index + direction;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    onChange({ ...doc, rujukan: next });
  };

  // Direktif handlers
  const addDirektif = (pejabatLabel: string) => {
    const newId = `dir-${Date.now()}`;
    const newDir: DirektifPejabat = {
      id: newId,
      pejabat: pejabatLabel,
      jenis: 'poin',
      poin: [
        {
          id: `poin-${Date.now()}`,
          teks: 'Melaksanakan koordinasi, pemetaan, dan pelaporan pelaksanaan tugas sesuai bidang fungsi masing-masing;',
        },
      ],
    };
    onChange({ ...doc, direktifList: [...doc.direktifList, newDir] });
    setExpandedDirektifId(newId);
  };

  const updateDirektif = (id: string, patch: Partial<DirektifPejabat>) => {
    onChange({
      ...doc,
      direktifList: doc.direktifList.map((d) => (d.id === id ? { ...d, ...patch } : d)),
    });
  };

  const removeDirektif = (id: string) => {
    onChange({
      ...doc,
      direktifList: doc.direktifList.filter((d) => d.id !== id),
    });
  };

  const moveDirektif = (index: number, direction: -1 | 1) => {
    const next = [...doc.direktifList];
    const target = index + direction;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    onChange({ ...doc, direktifList: next });
  };

  const addSubPoin = (direktifId: string) => {
    onChange({
      ...doc,
      direktifList: doc.direktifList.map((d) =>
        d.id === direktifId
          ? {
              ...d,
              poin: [
                ...d.poin,
                {
                  id: `sub-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
                  teks: 'Langkah pelaksanaan tugas berikutnya...',
                },
              ],
            }
          : d
      ),
    });
  };

  const updateSubPoin = (direktifId: string, subId: string, teks: string) => {
    onChange({
      ...doc,
      direktifList: doc.direktifList.map((d) =>
        d.id === direktifId
          ? {
              ...d,
              poin: d.poin.map((p) => (p.id === subId ? { ...p, teks } : p)),
            }
          : d
      ),
    });
  };

  const removeSubPoin = (direktifId: string, subId: string) => {
    onChange({
      ...doc,
      direktifList: doc.direktifList.map((d) =>
        d.id === direktifId
          ? {
              ...d,
              poin: d.poin.filter((p) => p.id !== subId),
            }
          : d
      ),
    });
  };

  const moveSubPoin = (direktifId: string, subIdx: number, direction: -1 | 1) => {
    onChange({
      ...doc,
      direktifList: doc.direktifList.map((d) => {
        if (d.id !== direktifId) return d;
        const next = [...d.poin];
        const target = subIdx + direction;
        if (target < 0 || target >= next.length) return d;
        [next[subIdx], next[target]] = [next[target], next[subIdx]];
        return { ...d, poin: next };
      }),
    });
  };

  // Tembusan handlers
  const addTembusan = () => {
    onChange({
      ...doc,
      tembusan: [...doc.tembusan, { id: `tem-${Date.now()}`, teks: 'Pejabat tembusan baru.' }],
    });
  };

  const updateTembusan = (id: string, teks: string) => {
    onChange({
      ...doc,
      tembusan: doc.tembusan.map((t) => (t.id === id ? { ...t, teks } : t)),
    });
  };

  const removeTembusan = (id: string) => {
    onChange({
      ...doc,
      tembusan: doc.tembusan.filter((t) => t.id !== id),
    });
  };

  const sections: { id: EditorSection; label: string }[] = [
    { id: 'identitas', label: '1. Kop & Nomor' },
    { id: 'rujukan', label: '2. Tujuan & Rujukan' },
    { id: 'direktif', label: '3. Isi & Direktif' },
    { id: 'penutup', label: '4. Penutup & TTD' },
  ];

  const inputClass =
    'w-full px-3 py-2 text-sm text-slate-900 bg-white border border-slate-200 rounded-md focus:outline-none focus:border-slate-900 focus:ring-1 focus:ring-slate-900 transition-colors';
  const labelClass = 'block text-xs font-medium text-slate-700 mb-1.5';

  return (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Document Title Bar */}
      <div className="px-5 py-3.5 border-b border-slate-200">
        <label htmlFor="doc-title-input" className="block text-xs font-medium text-slate-500 mb-1">
          Nama Draf Template
        </label>
        <input
          id="doc-title-input"
          type="text"
          value={doc.title}
          onChange={(e) => onChange({ ...doc, title: e.target.value })}
          className="w-full text-sm font-semibold text-slate-900 bg-transparent border-b border-transparent hover:border-slate-200 focus:border-slate-900 focus:outline-none py-0.5 transition-colors"
        />
        <div className="mt-1.5 flex items-center gap-2 text-xs text-slate-500 font-mono-code">
          <span>{formatNomorSurat(doc.identitas)}</span>
          <span aria-hidden="true">·</span>
          <span>{doc.direktifList.length} direktif</span>
        </div>
      </div>

      {/* Section Segmented Navigation */}
      <div className="px-4 py-2.5 border-b border-slate-200 bg-slate-50">
        <div className="grid grid-cols-2 gap-1.5">
          {sections.map((sec) => {
            const active = section === sec.id;
            return (
              <button
                key={sec.id}
                type="button"
                onClick={() => setSection(sec.id)}
                className={`px-2.5 py-1.5 text-xs font-medium rounded-md text-left whitespace-nowrap truncate transition-colors cursor-pointer ${
                  active
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-600 border border-slate-200 hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {sec.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable Form Body */}
      <div className="flex-1 overflow-y-auto workspace-scroll p-5 space-y-6">
        {section === 'identitas' && (
          <>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900">Kop Surat</h2>
                <label className="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={doc.kop.tampilkanEmblem}
                    onChange={(e) => updateKop({ tampilkanEmblem: e.target.checked })}
                    className="rounded border-slate-300 text-slate-900 focus:ring-slate-900"
                  />
                  <span>Lambang Tribrata</span>
                </label>
              </div>
              <div>
                <label className={labelClass}>Instansi Utama</label>
                <input
                  type="text"
                  value={doc.kop.instansi}
                  onChange={(e) => updateKop({ instansi: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>Satuan Induk / Daerah (dapat multi-baris)</label>
                <textarea
                  rows={2}
                  value={doc.kop.satuanInduk}
                  onChange={(e) => updateKop({ satuanInduk: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>Alamat Markas</label>
                <input
                  type="text"
                  value={doc.kop.alamat}
                  onChange={(e) => updateKop({ alamat: e.target.value })}
                  className={inputClass}
                />
              </div>
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h2 className="text-sm font-semibold text-slate-900">
                    Batas Margin Halaman (cm)
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5 font-mono-code tabular-nums">
                    Kiri {currentMargins.kiri} cm · Atas {currentMargins.atas} cm · Kanan{' '}
                    {currentMargins.kanan} cm · Bawah {currentMargins.bawah} cm
                  </p>
                </div>
                <button
                  type="button"
                  onClick={resetMargins}
                  className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md whitespace-nowrap cursor-pointer"
                >
                  Reset Default
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label htmlFor="margin-kiri" className={labelClass}>
                    Margin Kiri
                  </label>
                  <input
                    id="margin-kiri"
                    type="number"
                    min={0.5}
                    max={6}
                    step={0.1}
                    value={currentMargins.kiri}
                    onChange={(e) => updateMargin('kiri', e.target.value)}
                    className={`${inputClass} font-mono-code tabular-nums`}
                  />
                </div>
                <div>
                  <label htmlFor="margin-atas" className={labelClass}>
                    Margin Atas
                  </label>
                  <input
                    id="margin-atas"
                    type="number"
                    min={0.5}
                    max={6}
                    step={0.1}
                    value={currentMargins.atas}
                    onChange={(e) => updateMargin('atas', e.target.value)}
                    className={`${inputClass} font-mono-code tabular-nums`}
                  />
                </div>
                <div>
                  <label htmlFor="margin-kanan" className={labelClass}>
                    Margin Kanan
                  </label>
                  <input
                    id="margin-kanan"
                    type="number"
                    min={0.5}
                    max={6}
                    step={0.1}
                    value={currentMargins.kanan}
                    onChange={(e) => updateMargin('kanan', e.target.value)}
                    className={`${inputClass} font-mono-code tabular-nums`}
                  />
                </div>
                <div>
                  <label htmlFor="margin-bawah" className={labelClass}>
                    Margin Bawah
                  </label>
                  <input
                    id="margin-bawah"
                    type="number"
                    min={0.5}
                    max={6}
                    step={0.1}
                    value={currentMargins.bawah}
                    onChange={(e) => updateMargin('bawah', e.target.value)}
                    className={`${inputClass} font-mono-code tabular-nums`}
                  />
                </div>
              </div>
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-4">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Penomoran Surat (Format 6 Segmen)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5 font-mono-code">
                  Hasil: {formatNomorSurat(doc.identitas)}
                </p>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className={labelClass}>Kode Sifat</label>
                  <select
                    value={doc.identitas.klasifikasiKode}
                    onChange={(e) => {
                      const code = e.target.value as KlasifikasiKode;
                      const labelMap: Record<KlasifikasiKode, string> = {
                        B: 'Biasa',
                        R: 'Rahasia',
                        S: 'Sangat Rahasia',
                      };
                      updateIdentitas({
                        klasifikasiKode: code,
                        klasifikasiLabel: labelMap[code],
                      });
                    }}
                    className={inputClass}
                  >
                    <option value="B">B (Biasa)</option>
                    <option value="R">R (Rahasia)</option>
                    <option value="S">S (Sangat Rahasia)</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass}>No. Urut</label>
                  <input
                    type="text"
                    value={doc.identitas.nomorUrut}
                    onChange={(e) => updateIdentitas({ nomorUrut: e.target.value })}
                    className={`${inputClass} font-mono-code`}
                  />
                </div>
                <div>
                  <label className={labelClass}>Bulan Romawi</label>
                  <select
                    value={doc.identitas.bulanRomawi}
                    onChange={(e) => updateIdentitas({ bulanRomawi: e.target.value })}
                    className={`${inputClass} font-mono-code`}
                  >
                    {MONTHS_ROMAN.map((m) => (
                      <option key={m.roman} value={m.roman}>
                        {m.roman} ({m.label})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className={labelClass}>Kode Klasifikasi</label>
                  <input
                    type="text"
                    value={doc.identitas.kodeKlasifikasi}
                    onChange={(e) => updateIdentitas({ kodeKlasifikasi: e.target.value })}
                    placeholder="OPS.2.1."
                    className={`${inputClass} font-mono-code`}
                  />
                </div>
                <div>
                  <label className={labelClass}>Tahun</label>
                  <input
                    type="text"
                    value={doc.identitas.tahun}
                    onChange={(e) => updateIdentitas({ tahun: e.target.value })}
                    className={`${inputClass} font-mono-code`}
                  />
                </div>
                <div>
                  <label className={labelClass}>Satker</label>
                  <input
                    type="text"
                    value={doc.identitas.satkerPenerbit}
                    onChange={(e) => updateIdentitas({ satkerPenerbit: e.target.value })}
                    placeholder="Roops"
                    className={inputClass}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Klasifikasi Surat</label>
                  <input
                    type="text"
                    value={doc.identitas.klasifikasiLabel}
                    onChange={(e) => updateIdentitas({ klasifikasiLabel: e.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>Lampiran</label>
                  <input
                    type="text"
                    value={doc.identitas.lampiran}
                    onChange={(e) => updateIdentitas({ lampiran: e.target.value })}
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Hal / Perihal (diawali huruf kecil sesuai standar)</label>
                <textarea
                  rows={3}
                  value={doc.identitas.hal}
                  onChange={(e) => updateIdentitas({ hal: e.target.value })}
                  className={inputClass}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Tempat Ditetapkan</label>
                  <input
                    type="text"
                    value={doc.identitas.tempat}
                    onChange={(e) => updateIdentitas({ tempat: e.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>Tanggal Surat</label>
                  <input
                    type="text"
                    value={doc.identitas.tanggal}
                    onChange={(e) => updateIdentitas({ tanggal: e.target.value })}
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Judul Header Halaman Lanjutan (Halaman 2+)</label>
                <input
                  type="text"
                  value={doc.identitas.headerLanjutanJudul}
                  onChange={(e) => updateIdentitas({ headerLanjutanJudul: e.target.value })}
                  placeholder="SURAT KAPOLDA JATENG"
                  className={inputClass}
                />
              </div>
            </div>
          </>
        )}

        {section === 'rujukan' && (
          <>
            <div className="space-y-4">
              <h2 className="text-sm font-semibold text-slate-900">Tajuk Alamat (Kepada)</h2>
              <div>
                <label className={labelClass}>Yth. (Tujuan Surat)</label>
                <textarea
                  rows={2}
                  value={doc.tujuan.kepada}
                  onChange={(e) => updateTujuan({ kepada: e.target.value })}
                  className={inputClass}
                />
              </div>
              <div>
                <label className={labelClass}>Kota / Tempat Tujuan (di ...)</label>
                <input
                  type="text"
                  value={doc.tujuan.tempatTujuan}
                  onChange={(e) => updateTujuan({ tempatTujuan: e.target.value })}
                  className={inputClass}
                />
              </div>
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900">1. Rujukan</h2>
                <button
                  type="button"
                  onClick={addRujukan}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Tambah Rujukan</span>
                </button>
              </div>

              {doc.rujukan.length === 0 ? (
                <div className="p-4 border border-dashed border-slate-300 rounded-md text-center">
                  <p className="text-xs text-slate-500">Belum ada poin rujukan.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {doc.rujukan.map((item, idx) => (
                    <div
                      key={item.id}
                      className="p-3 border border-slate-200 rounded-md bg-slate-50/50 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-700 font-mono-code">
                          Rujukan {String.fromCharCode(97 + idx)}.
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => moveRujukan(idx, -1)}
                            disabled={idx === 0}
                            aria-label="Geser ke atas"
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveRujukan(idx, 1)}
                            disabled={idx === doc.rujukan.length - 1}
                            aria-label="Geser ke bawah"
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => removeRujukan(item.id)}
                            aria-label="Hapus rujukan"
                            className="p-1 text-slate-500 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <textarea
                        rows={3}
                        value={item.teks}
                        onChange={(e) => updateRujukan(item.id, e.target.value)}
                        className={inputClass}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {section === 'direktif' && (
          <>
            <div className="space-y-4">
              <h2 className="text-sm font-semibold text-slate-900">
                2. Latar Belakang & Situasi
              </h2>
              <textarea
                rows={6}
                value={doc.latarBelakang}
                onChange={(e) => onChange({ ...doc, latarBelakang: e.target.value })}
                className={inputClass}
              />
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-4">
              <h2 className="text-sm font-semibold text-slate-900">
                3. Kalimat Pengantar Perintah
              </h2>
              <textarea
                rows={3}
                value={doc.pembukaDirektif}
                onChange={(e) => onChange({ ...doc, pembukaDirektif: e.target.value })}
                className={inputClass}
              />
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-semibold text-slate-900">
                  Direktif Per Pejabat / Fungsi
                </h2>
                <span className="text-xs text-slate-500 font-mono-code">
                  {doc.direktifList.length} bagian
                </span>
              </div>

              {/* Quick Insert Bar */}
              <div className="p-3 border border-slate-200 rounded-md bg-slate-50 space-y-2">
                <label className="block text-xs font-medium text-slate-700">
                  Tambah Pejabat / Satker Baru
                </label>
                <div className="flex items-center gap-2">
                  <select
                    value={selectedQuickPejabat}
                    onChange={(e) => setSelectedQuickPejabat(e.target.value)}
                    className={`${inputClass} flex-1`}
                  >
                    {STANDARD_PEJABAT_SUGGESTIONS.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => addDirektif(selectedQuickPejabat)}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md shrink-0 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Tambah</span>
                  </button>
                </div>
              </div>

              {/* Directive List */}
              <div className="space-y-2.5">
                {doc.direktifList.map((dir, dIdx) => {
                  const letter = String.fromCharCode(97 + dIdx);
                  const isExpanded = expandedDirektifId === dir.id;
                  return (
                    <div
                      key={dir.id}
                      className="border border-slate-200 rounded-md bg-white overflow-hidden"
                    >
                      <div className="px-3 py-2.5 bg-slate-50 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedDirektifId(isExpanded ? null : dir.id)
                          }
                          className="flex-1 text-left text-xs font-semibold text-slate-900 truncate cursor-pointer"
                        >
                          <span className="font-mono-code mr-1.5">{letter}.</span>
                          {dir.pejabat}
                        </button>
                        <div className="flex items-center gap-1 shrink-0">
                          <span className="text-[11px] text-slate-500 mr-1 font-mono-code">
                            {dir.jenis === 'paragraf' ? 'Paragraf' : `${dir.poin.length} poin`}
                          </span>
                          <button
                            type="button"
                            onClick={() => moveDirektif(dIdx, -1)}
                            disabled={dIdx === 0}
                            aria-label="Naikkan direktif"
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveDirektif(dIdx, 1)}
                            disabled={dIdx === doc.direktifList.length - 1}
                            aria-label="Turunkan direktif"
                            className="p-1 text-slate-500 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => removeDirektif(dir.id)}
                            aria-label="Hapus direktif"
                            className="p-1 text-slate-500 hover:text-red-600 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="p-3 space-y-3 border-t border-slate-200">
                          <div className="flex items-center justify-between gap-2">
                            <label className="text-xs font-medium text-slate-700">
                              Format Bagian
                            </label>
                            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-md">
                              <button
                                type="button"
                                onClick={() => updateDirektif(dir.id, { jenis: 'poin' })}
                                className={`px-2 py-1 text-xs font-medium rounded cursor-pointer ${
                                  dir.jenis === 'poin'
                                    ? 'bg-white text-slate-900 shadow-xs'
                                    : 'text-slate-600'
                                }`}
                              >
                                Daftar 1), 2)
                              </button>
                              <button
                                type="button"
                                onClick={() => updateDirektif(dir.id, { jenis: 'paragraf' })}
                                className={`px-2 py-1 text-xs font-medium rounded cursor-pointer ${
                                  dir.jenis === 'paragraf'
                                    ? 'bg-white text-slate-900 shadow-xs'
                                    : 'text-slate-600'
                                }`}
                              >
                                Paragraf Tunggal
                              </button>
                            </div>
                          </div>

                          <div>
                            <label className={labelClass}>
                              {dir.jenis === 'paragraf'
                                ? 'Teks Paragraf Direktif'
                                : 'Kalimat Sasaran Pejabat (mis. Kepada Dirintelkam agar:)'}
                            </label>
                            <textarea
                              rows={dir.jenis === 'paragraf' ? 4 : 2}
                              value={dir.pejabat}
                              onChange={(e) =>
                                updateDirektif(dir.id, { pejabat: e.target.value })
                              }
                              className={inputClass}
                            />
                          </div>

                          {dir.jenis === 'poin' && (
                            <div className="space-y-2.5">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-medium text-slate-700">
                                  Sub-poin Tindakan
                                </span>
                                <button
                                  type="button"
                                  onClick={() => addSubPoin(dir.id)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium text-slate-900 bg-slate-100 hover:bg-slate-200 rounded cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" aria-hidden="true" />
                                  <span>Tambah Poin</span>
                                </button>
                              </div>

                              {dir.poin.map((sub, sIdx) => (
                                <div key={sub.id} className="space-y-1">
                                  <div className="flex items-center justify-between">
                                    <span className="text-xs font-mono-code text-slate-500">
                                      {sIdx + 1})
                                    </span>
                                    <div className="flex items-center gap-1">
                                      <button
                                        type="button"
                                        onClick={() => moveSubPoin(dir.id, sIdx, -1)}
                                        disabled={sIdx === 0}
                                        className="p-0.5 text-slate-400 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                                        aria-label="Naikkan sub-poin"
                                      >
                                        <ArrowUp className="w-3 h-3" />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => moveSubPoin(dir.id, sIdx, 1)}
                                        disabled={sIdx === dir.poin.length - 1}
                                        className="p-0.5 text-slate-400 hover:text-slate-900 disabled:opacity-30 cursor-pointer"
                                        aria-label="Turunkan sub-poin"
                                      >
                                        <ArrowDown className="w-3 h-3" />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => removeSubPoin(dir.id, sub.id)}
                                        className="p-0.5 text-slate-400 hover:text-red-600 cursor-pointer"
                                        aria-label="Hapus sub-poin"
                                      >
                                        <Trash2 className="w-3 h-3" />
                                      </button>
                                    </div>
                                  </div>
                                  <textarea
                                    rows={3}
                                    value={sub.teks}
                                    onChange={(e) =>
                                      updateSubPoin(dir.id, sub.id, e.target.value)
                                    }
                                    className={inputClass}
                                  />
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        {section === 'penutup' && (
          <>
            <div className="space-y-4">
              <h2 className="text-sm font-semibold text-slate-900">
                4. Kalimat Penutup & Pelaporan
              </h2>
              <textarea
                rows={5}
                value={doc.penutup}
                onChange={(e) => onChange({ ...doc, penutup: e.target.value })}
                className={inputClass}
              />
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900">Tajuk Tanda Tangan</h2>
                <label className="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={doc.penandaTangan.tampilkanStempel}
                    onChange={(e) =>
                      updatePenandaTangan({ tampilkanStempel: e.target.checked })
                    }
                    className="rounded border-slate-300 text-slate-900 focus:ring-slate-900"
                  />
                  <span>Pratinjau Stempel</span>
                </label>
              </div>

              <div className="grid grid-cols-4 gap-3">
                <div>
                  <label className={labelClass}>Pelimpahan</label>
                  <input
                    type="text"
                    value={doc.penandaTangan.atasNama}
                    onChange={(e) => updatePenandaTangan({ atasNama: e.target.value })}
                    placeholder="a.n."
                    className={inputClass}
                  />
                </div>
                <div className="col-span-3">
                  <label className={labelClass}>Jabatan Pimpinan Utama</label>
                  <input
                    type="text"
                    value={doc.penandaTangan.jabatanUtama}
                    onChange={(e) => updatePenandaTangan({ jabatanUtama: e.target.value })}
                    className={inputClass}
                  />
                </div>
              </div>

              <div>
                <label className={labelClass}>Jabatan Penanda Tangan</label>
                <input
                  type="text"
                  value={doc.penandaTangan.jabatanPenandaTangan}
                  onChange={(e) =>
                    updatePenandaTangan({ jabatanPenandaTangan: e.target.value })
                  }
                  className={inputClass}
                />
              </div>

              <div>
                <label className={labelClass}>Nama Lengkap & Gelar</label>
                <input
                  type="text"
                  value={doc.penandaTangan.nama}
                  onChange={(e) => updatePenandaTangan({ nama: e.target.value })}
                  className={inputClass}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelClass}>Pangkat</label>
                  <input
                    type="text"
                    value={doc.penandaTangan.pangkat}
                    onChange={(e) => updatePenandaTangan({ pangkat: e.target.value })}
                    className={inputClass}
                  />
                </div>
                <div>
                  <label className={labelClass}>NRP</label>
                  <input
                    type="text"
                    value={doc.penandaTangan.nrp}
                    onChange={(e) => updatePenandaTangan({ nrp: e.target.value })}
                    className={`${inputClass} font-mono-code`}
                  />
                </div>
              </div>
            </div>

            <hr className="border-slate-200" />

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900">Tembusan</h2>
                <button
                  type="button"
                  onClick={addTembusan}
                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Tambah</span>
                </button>
              </div>
              {doc.tembusan.map((item, idx) => (
                <div key={item.id} className="flex items-center gap-2">
                  <span className="text-xs font-mono-code text-slate-500 w-5">
                    {idx + 1}.
                  </span>
                  <input
                    type="text"
                    value={item.teks}
                    onChange={(e) => updateTembusan(item.id, e.target.value)}
                    className={`${inputClass} flex-1`}
                  />
                  <button
                    type="button"
                    onClick={() => removeTembusan(item.id)}
                    aria-label="Hapus tembusan"
                    className="p-1.5 text-slate-400 hover:text-red-600 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
