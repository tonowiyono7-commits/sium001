import React, { useMemo, useState } from 'react';
import { ArrowRight, ExternalLink, Search } from 'lucide-react';
import {
  REFERENCE_ANATOMY_SECTIONS,
  REFERENCE_LETTER,
  REFERENCE_PDF_URL,
} from '../data/referenceLetter';

interface ReferenceAnalysisViewProps {
  onUseReferenceAsTemplate: () => void;
}

export const ReferenceAnalysisView: React.FC<ReferenceAnalysisViewProps> = ({
  onUseReferenceAsTemplate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showPdfEmbed, setShowPdfEmbed] = useState(false);

  const totalSubPoints = useMemo(() => {
    return REFERENCE_LETTER.direktifList.reduce(
      (sum, d) => sum + (d.jenis === 'paragraf' ? 1 : d.poin.length),
      0
    );
  }, []);

  const filteredDirectives = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return REFERENCE_LETTER.direktifList
      .map((d, idx) => ({
        ...d,
        huruf: String.fromCharCode(97 + idx),
      }))
      .filter((d) => {
        if (!q) return true;
        const inHeader = d.pejabat.toLowerCase().includes(q);
        const inPoints = d.poin.some((p) => p.teks.toLowerCase().includes(q));
        return inHeader || inPoints;
      });
  }, [searchQuery]);

  const nomorSegments = [
    { segmen: 'B', arti: 'Klasifikasi Surat', keterangan: 'B = Biasa, R = Rahasia, S = Sangat Rahasia' },
    { segmen: '14381', arti: 'Nomor Urut Register', keterangan: 'Nomor urut agenda keluar Satker' },
    { segmen: 'XI', arti: 'Bulan Penerbitan', keterangan: 'Angka Romawi bulan November' },
    { segmen: 'OPS.2.1.', arti: 'Kode Klasifikasi Arsip', keterangan: 'Bidang Operasional / Kesiapsiagaan' },
    { segmen: '2026', arti: 'Tahun Anggaran', keterangan: 'Tahun penetapan naskah dinas' },
    { segmen: 'Roops', arti: 'Satker Konseptor', keterangan: 'Biro Operasi Polda Jawa Tengah' },
  ];

  return (
    <div className="max-w-6xl mx-auto px-6 py-10 space-y-12">
      {/* Header Summary */}
      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 pb-8 border-b border-slate-200">
        <div className="max-w-3xl space-y-2">
          <div className="text-xs font-medium text-slate-500">
            Hasil Analisis Dokumen Referensi · Surat Kapolda Jateng
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 text-balance">
            Anatomi Surat Biasa Petunjuk dan Arahan (Jukrah)
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Bedah struktur dokumen resmi{' '}
            <span className="font-mono-code text-slate-900 font-medium">
              B/14381/XI/OPS.2.1./2026/Roops
            </span>{' '}
            tanggal 13 November 2026 tentang petunjuk dan arahan antisipasi serta penanganan
            bencana hidrometeorologi di wilayah hukum Polda Jawa Tengah.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setShowPdfEmbed((v) => !v)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            <span>{showPdfEmbed ? 'Tutup PDF Asli' : 'Lihat PDF Asli'}</span>
          </button>
          <button
            type="button"
            onClick={onUseReferenceAsTemplate}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            <span>Muat ke Editor Template</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        </div>
      </section>

      {/* Optional Embedded Reference PDF Viewer */}
      {showPdfEmbed && (
        <section className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div className="text-xs font-medium text-slate-700">
              Dokumen Asli: B-14381 Jukrah Antisipasi Bencana Hidrometeorologi (12 Halaman)
            </div>
            <a
              href={REFERENCE_PDF_URL}
              download="B-14381_Jukrah_Polda_Jateng.pdf"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-900 hover:underline"
            >
              <span>Unduh PDF</span>
              <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
            </a>
          </div>
          <iframe
            src={REFERENCE_PDF_URL}
            title="Pratinjau Dokumen PDF Referensi"
            className="w-full h-[640px] bg-slate-100"
          />
        </section>
      )}

      {/* Key Metrics Strip (unboxed clean grid, tabular figures) */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-6 border border-slate-200 rounded-lg bg-white p-6">
        <div>
          <div className="text-xs text-slate-500">Total Halaman</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">12 Halaman</div>
          <div className="mt-1 text-xs text-slate-500">Halaman 2–12 wajib header lanjutan</div>
        </div>
        <div>
          <div className="text-xs text-slate-500">Sasaran Pejabat / Satker</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
            {REFERENCE_LETTER.direktifList.length} Bagian
          </div>
          <div className="mt-1 text-xs text-slate-500">Huruf a. sampai dengan q.</div>
        </div>
        <div>
          <div className="text-xs text-slate-500">Total Poin Instruksi</div>
          <div className="mt-1 text-2xl font-bold text-slate-900 tabular-nums">
            {totalSubPoints} Poin
          </div>
          <div className="mt-1 text-xs text-slate-500">Terbanyak pada Kapolres/Ta/Tabes (17)</div>
        </div>
        <div>
          <div className="text-xs text-slate-500">Klasifikasi & Sifat</div>
          <div className="mt-1 text-2xl font-bold text-slate-900">Biasa (Perintah)</div>
          <div className="mt-1 text-xs text-slate-500">Penandatangan a.n. Kapolda · Karoops</div>
        </div>
      </section>

      {/* Numbering Breakdown */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            01. Struktur Penomoran Surat 6 Segmen
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Setiap segmen pada nomor surat{' '}
            <span className="font-mono-code text-slate-900">
              B/14381/XI/OPS.2.1./2026/Roops
            </span>{' '}
            memiliki fungsi administratif baku yang telah diotomatisasi pada Editor Surat.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {nomorSegments.map((item) => (
            <div
              key={item.arti}
              className="p-4 border border-slate-200 rounded-lg bg-white space-y-1.5"
            >
              <div className="text-lg font-bold text-slate-900 font-mono-code">
                {item.segmen}
              </div>
              <div className="text-xs font-semibold text-slate-800">{item.arti}</div>
              <div className="text-xs text-slate-500 leading-relaxed">
                {item.keterangan}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8-Part Structural Anatomy Table */}
      <section className="space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">
            02. Delapan Komponen Tata Naskah Dinas
          </h2>
          <p className="text-sm text-slate-600 mt-1">
            Pemetaan menyeluruh tata letak, tipografi, tanda baca, dan hierarki penomoran dari
            halaman 1 hingga halaman 12.
          </p>
        </div>

        <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700">
                  <th className="py-3 px-4 w-14">No.</th>
                  <th className="py-3 px-4 w-56">Bagian Dokumen</th>
                  <th className="py-3 px-4 w-48">Posisi Tata Letak</th>
                  <th className="py-3 px-4">Aturan Format & Catatan Teknis</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {REFERENCE_ANATOMY_SECTIONS.map((sec) => (
                  <tr key={sec.id} className="hover:bg-slate-50/70 align-top">
                    <td className="py-3.5 px-4 font-mono-code text-xs text-slate-500 tabular-nums">
                      {sec.urutan}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      {sec.bagian}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600">{sec.posisi}</td>
                    <td className="py-3.5 px-4 space-y-1.5">
                      <p className="text-slate-700 text-xs leading-relaxed">
                        {sec.aturanFormat}
                      </p>
                      <p className="text-slate-500 text-xs leading-relaxed font-mono-code">
                        Contoh: {sec.contohReferensi}
                      </p>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Directive Distribution Matrix */}
      <section className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold text-slate-900">
              03. Matriks Direktif Per Pejabat & Fungsi (a. s.d. q.)
            </h2>
            <p className="text-sm text-slate-600 mt-1">
              Rincian pembagian peran lintas fungsi kepolisian dalam surat referensi B/14381.
            </p>
          </div>

          <div className="relative w-full sm:w-72">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari pejabat atau kata kunci..."
              className="w-full pl-9 pr-3 py-2 text-xs text-slate-900 bg-white border border-slate-200 rounded-md focus:outline-none focus:border-slate-900"
            />
          </div>
        </div>

        <div className="border border-slate-200 rounded-lg bg-white overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700">
                  <th className="py-3 px-4 w-16">Huruf</th>
                  <th className="py-3 px-4 w-64">Pejabat / Sasaran</th>
                  <th className="py-3 px-4">Ringkasan Fokus Instruksi</th>
                  <th className="py-3 px-4 w-28 text-right">Jumlah Poin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-xs">
                {filteredDirectives.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-500">
                      Tidak ditemukan direktif yang cocok dengan kata kunci &ldquo;{searchQuery}&rdquo;.
                    </td>
                  </tr>
                ) : (
                  filteredDirectives.map((d) => {
                    const summaryText =
                      d.jenis === 'paragraf'
                        ? d.pejabat
                        : d.poin.map((p) => p.teks.replace(/;$/, '')).slice(0, 2).join(' · ');

                    const cleanPejabat =
                      d.jenis === 'paragraf'
                        ? 'Kepada Kabid Labfor (Paragraf Bersyarat)'
                        : d.pejabat.replace(/\s*agar\s*:?\s*$/i, '');

                    return (
                      <tr key={d.id} className="hover:bg-slate-50/70 align-top">
                        <td className="py-3 px-4 font-mono-code font-semibold text-slate-900">
                          {d.huruf}.
                        </td>
                        <td className="py-3 px-4 font-medium text-slate-900">
                          {cleanPejabat}
                        </td>
                        <td className="py-3 px-4 text-slate-600 leading-relaxed">
                          {summaryText}
                        </td>
                        <td className="py-3 px-4 text-right font-mono-code tabular-nums text-slate-700">
                          {d.jenis === 'paragraf' ? '1 (paragraf)' : `${d.poin.length} poin`}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
    </div>
  );
};
