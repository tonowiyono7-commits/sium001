import React, { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  Check,
  ChevronLeft,
  ChevronRight,
  Columns2,
  Copy,
  FileDown,
  Printer,
  Ruler,
  Square,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { DEFAULT_MARGINS, formatNomorSurat } from '../data/referenceLetter';
import { LetterDocument } from '../types/letter';
import { letterToPlainText } from '../utils/exportDoc';
import { exportLetterToDocx } from '../utils/exportDocx';
import { exportLetterToPdf } from '../utils/exportPdf';
import { OfficialStamp, TribrataEmblem } from './TribrataEmblem';

export type PreviewMode = 'paginated' | 'continuous';

export interface PageBlock {
  kind:
    | 'kop-and-meta'
    | 'rujukan-header'
    | 'rujukan-item'
    | 'latar-belakang'
    | 'pembuka-direktif'
    | 'direktif-header'
    | 'direktif-subpoin'
    | 'direktif-paragraf'
    | 'penutup'
    | 'ttd-tembusan';
  letterPrefix?: string;
  subIndex?: number;
  text?: string;
  pejabat?: string;
  isLastRujukan?: boolean;
  isContinuation?: boolean;
  isSplitStart?: boolean;
}

function buildRawBlocks(doc: LetterDocument): PageBlock[] {
  const blocks: PageBlock[] = [];

  blocks.push({ kind: 'kop-and-meta' });

  if (doc.rujukan.length > 0) {
    blocks.push({ kind: 'rujukan-header' });
    doc.rujukan.forEach((r, idx) => {
      blocks.push({
        kind: 'rujukan-item',
        letterPrefix: String.fromCharCode(97 + idx),
        text: r.teks,
        isLastRujukan: idx === doc.rujukan.length - 1,
      });
    });
  }

  blocks.push({
    kind: 'latar-belakang',
    text: doc.latarBelakang,
  });

  blocks.push({
    kind: 'pembuka-direktif',
    text: doc.pembukaDirektif,
  });

  doc.direktifList.forEach((dir, dIdx) => {
    const letter = String.fromCharCode(97 + dIdx);
    if (dir.jenis === 'paragraf') {
      blocks.push({
        kind: 'direktif-paragraf',
        letterPrefix: letter,
        pejabat: dir.pejabat,
      });
    } else {
      blocks.push({
        kind: 'direktif-header',
        letterPrefix: letter,
        pejabat: dir.pejabat,
      });
      dir.poin.forEach((sub, sIdx) => {
        blocks.push({
          kind: 'direktif-subpoin',
          subIndex: sIdx + 1,
          text: sub.teks,
        });
      });
    }
  });

  blocks.push({
    kind: 'penutup',
    text: doc.penutup,
  });

  blocks.push({ kind: 'ttd-tembusan' });

  return blocks;
}

function isSplittableBlock(block: PageBlock): boolean {
  return (
    block.kind === 'rujukan-item' ||
    block.kind === 'latar-belakang' ||
    block.kind === 'pembuka-direktif' ||
    block.kind === 'direktif-subpoin' ||
    block.kind === 'direktif-paragraf' ||
    block.kind === 'penutup'
  );
}

function getBlockText(block: PageBlock): string {
  if (block.kind === 'direktif-paragraf') return block.pejabat ?? '';
  return block.text ?? '';
}

function cloneBlockWithText(
  block: PageBlock,
  newText: string,
  flags: { isContinuation?: boolean; isSplitStart?: boolean }
): PageBlock {
  const next: PageBlock = {
    ...block,
    isContinuation: flags.isContinuation ?? block.isContinuation,
    isSplitStart: flags.isSplitStart ?? false,
  };
  if (block.kind === 'direktif-paragraf') {
    next.pejabat = newText;
  } else {
    next.text = newText;
  }
  return next;
}

/**
 * Fallback synchronous estimate before first DOM layout measurement completes.
 */
export function paginateDocument(doc: LetterDocument): PageBlock[][] {
  return [buildRawBlocks(doc)];
}

interface LetterDocumentPagesProps {
  doc: LetterDocument;
  mode: PreviewMode;
  zoom?: number;
  columns?: 1 | 2;
  showMarginGuides?: boolean;
  showPageLabels?: boolean;
  pageRefs?: React.MutableRefObject<(HTMLElement | null)[]>;
  onPageCountChange?: (count: number) => void;
}

export const LetterDocumentPages: React.FC<LetterDocumentPagesProps> = ({
  doc,
  mode,
  zoom = 1,
  columns = 1,
  showMarginGuides = false,
  showPageLabels = false,
  pageRefs,
  onPageCountChange,
}) => {
  const nomorLengkap = formatNomorSurat(doc.identitas);
  const margins = doc.margins ?? DEFAULT_MARGINS;
  const rawBlocks = useMemo(() => buildRawBlocks(doc), [doc]);

  const [measuredPages, setMeasuredPages] = useState<PageBlock[][]>(() => [rawBlocks]);
  const [measureTick, setMeasureTick] = useState(0);

  const measureRootRef = useRef<HTMLDivElement | null>(null);
  const bodyCalibratorRef = useRef<HTMLDivElement | null>(null);
  const contHeaderMeasureRef = useRef<HTMLDivElement | null>(null);
  const probeTextRef = useRef<HTMLParagraphElement | null>(null);

  const pagePaddingStyle: React.CSSProperties = {
    padding: `${margins.atas}cm ${margins.kanan}cm ${margins.bawah}cm ${margins.kiri}cm`,
  };
  const dynamicPrintRule = `@media print { @page { size: A4 portrait; margin: ${margins.atas}cm ${margins.kanan}cm ${margins.bawah}cm ${margins.kiri}cm; } }`;

  const renderKopAndMeta = () => (
    <>
      {/* Row 1: Kop Surat & Tanggal (Semarang aligned with Yth.) */}
      <div className="grid grid-cols-[58%_42%] items-end mb-4">
        <div className="flex flex-col items-center text-center">
          {doc.kop.tampilkanEmblem && (
            <TribrataEmblem className="h-14 w-auto mb-1.5" />
          )}
          <div className="text-[11pt] leading-[1.2] tracking-normal">
            {doc.kop.instansi}
          </div>
          <div className="text-[11pt] leading-[1.2] whitespace-pre-line">
            {doc.kop.satuanInduk}
          </div>
          <div className="text-[10.5pt] leading-[1.2] border-b border-black pb-[2px] px-2">
            {doc.kop.alamat}
          </div>
        </div>

        <div className="pl-5 text-left text-[11pt] pb-[2px] whitespace-nowrap">
          {doc.identitas.tempat}, &nbsp;{doc.identitas.tanggal}
        </div>
      </div>

      {/* Row 2: Identitas Surat (Left) & Kepada aligned with last line of Hal and column of DISTRIBUSI */}
      <div className="grid grid-cols-[58%_42%] items-end">
        <div>
          <table className="w-full text-[11pt] leading-[1.32] border-collapse">
            <tbody>
              <tr>
                <td className="w-[74pt] align-top">Nomor</td>
                <td className="w-[10pt] align-top">:</td>
                <td className="align-top">{nomorLengkap}</td>
              </tr>
              <tr>
                <td className="align-top">Klasifikasi</td>
                <td className="align-top">:</td>
                <td className="align-top">{doc.identitas.klasifikasiLabel}</td>
              </tr>
              <tr>
                <td className="align-top">Lampiran</td>
                <td className="align-top">:</td>
                <td className="align-top">{doc.identitas.lampiran}</td>
              </tr>
              <tr>
                <td className="align-top">Hal</td>
                <td className="align-top">:</td>
                <td className="align-top">{doc.identitas.hal}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div className="pl-5 text-[11pt] leading-[1.32]">
          <div className="flex items-start">
            <span className="w-[34px] shrink-0" aria-hidden="true" />
            <span>Kepada</span>
          </div>
        </div>
      </div>

      {/* Row 3: Yth. aligned with Semarang, DISTRIBUSI / di / Tempat aligned with Kepada */}
      <div className="grid grid-cols-[58%_42%] items-start mt-2.5">
        <div aria-hidden="true" />
        <div className="pl-5 text-[11pt] leading-[1.32]">
          <div className="flex items-start">
            <span className="w-[34px] shrink-0">Yth.</span>
            <span className="flex-1 whitespace-pre-line">{doc.tujuan.kepada}</span>
          </div>
          <div className="flex items-start mt-2.5">
            <span className="w-[34px] shrink-0" aria-hidden="true" />
            <span className="flex-1">di</span>
          </div>
          <div className="flex items-start mt-2.5">
            <span className="w-[34px] shrink-0" aria-hidden="true" />
            <span className="flex-1">{doc.tujuan.tempatTujuan}</span>
          </div>
        </div>
      </div>
    </>
  );

  const renderContinuationHeader = (pageNumber: number) => (
    <div className="flex justify-end mb-6 text-[10.5pt] leading-[1.28]">
      <div className="flex items-start gap-4">
        <span className="tabular-nums">{pageNumber}</span>
        <div>
          <div className="underline underline-offset-2">
            {doc.identitas.headerLanjutanJudul}
          </div>
          <div className="underline underline-offset-2">
            NOMOR &nbsp;&nbsp;: {nomorLengkap.toUpperCase()}
          </div>
          <div className="underline underline-offset-2">
            TANGGAL: {doc.identitas.tanggal.toUpperCase()}
          </div>
        </div>
      </div>
    </div>
  );

  const renderTtdAndTembusan = () => {
    const atasNamaPrefix = doc.penandaTangan.atasNama.trim()
      ? `${doc.penandaTangan.atasNama.trim()} `
      : '';

    return (
      <>
        <div className="flex justify-end">
          <div className="w-fit min-w-[54%] max-w-full text-center text-[11pt] leading-[1.3] relative">
            <div className="whitespace-nowrap">
              {atasNamaPrefix}
              {doc.penandaTangan.jabatanUtama}
            </div>
            <div>{doc.penandaTangan.jabatanPenandaTangan}</div>

            <div className="h-[68px] relative flex items-center justify-center">
              {doc.penandaTangan.tampilkanStempel && (
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 pointer-events-none">
                  <OfficialStamp
                    satuan={doc.penandaTangan.stempelSatuan}
                    jabatan={doc.penandaTangan.stempelJabatan}
                    className="w-28 h-28"
                  />
                </div>
              )}
            </div>

            <div className="flex flex-col items-center">
              <div
                className={
                  `${doc.penandaTangan.pangkat} ${doc.penandaTangan.nrp}`.trim()
                    ? 'pb-[1px]'
                    : 'underline underline-offset-2'
                }
              >
                {doc.penandaTangan.nama}
              </div>
              {`${doc.penandaTangan.pangkat} ${doc.penandaTangan.nrp}`.trim() && (
                <div className="w-fit border-t border-black pt-[1px] whitespace-nowrap">
                  {doc.penandaTangan.pangkat} {doc.penandaTangan.nrp}
                </div>
              )}
            </div>
          </div>
        </div>

        {doc.tembusan.length > 0 && (
          <div className="mt-5 text-[11pt] leading-[1.32]">
            <div className="mb-1">Tembusan:</div>
            <div className="space-y-0.5">
              {doc.tembusan.map((t, idx) => (
                <div key={t.id} className="flex items-start gap-2">
                  <span className="w-5 shrink-0">{idx + 1}.</span>
                  <span>{t.teks}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </>
    );
  };

  const renderBlock = (block: PageBlock, idx: number, isMeasure = false) => {
    const justifyStyle: React.CSSProperties | undefined = block.isSplitStart
      ? { textAlign: 'justify', textAlignLast: 'justify' }
      : undefined;

    const wrapAttr = isMeasure ? { 'data-measure-idx': idx } : {};

    switch (block.kind) {
      case 'kop-and-meta':
        return (
          <div key={`b-${idx}`} {...wrapAttr} className="mb-5">
            {renderKopAndMeta()}
          </div>
        );

      case 'rujukan-header':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className="flex items-start text-[11pt] leading-[1.38] mb-1.5"
          >
            <span className="w-8 shrink-0">1.</span>
            <div className="flex-1">Rujukan:</div>
          </div>
        );

      case 'rujukan-item':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className={`flex items-start text-[11pt] leading-[1.38] ${
              block.isContinuation ? 'pl-[60px]' : 'pl-8'
            } ${block.isLastRujukan ? 'mb-3' : 'mb-1.5'}`}
          >
            {!block.isContinuation && (
              <span className="w-7 shrink-0">{block.letterPrefix}.</span>
            )}
            <p
              data-measure-text={isMeasure ? 'true' : undefined}
              className="flex-1 text-justify"
              style={justifyStyle}
            >
              {block.text}
            </p>
          </div>
        );

      case 'latar-belakang':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className={`flex items-start text-[11pt] leading-[1.38] mb-3 ${
              block.isContinuation ? 'pl-8' : ''
            }`}
          >
            {!block.isContinuation && <span className="w-8 shrink-0">2.</span>}
            <p
              data-measure-text={isMeasure ? 'true' : undefined}
              className="flex-1 text-justify"
              style={justifyStyle}
            >
              {block.text}
            </p>
          </div>
        );

      case 'pembuka-direktif':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className={`flex items-start text-[11pt] leading-[1.38] mb-2.5 ${
              block.isContinuation ? 'pl-8' : ''
            }`}
          >
            {!block.isContinuation && <span className="w-8 shrink-0">3.</span>}
            <p
              data-measure-text={isMeasure ? 'true' : undefined}
              className="flex-1 text-justify"
              style={justifyStyle}
            >
              {block.text}
            </p>
          </div>
        );

      case 'direktif-header':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className="flex items-start text-[11pt] leading-[1.38] pl-8 mt-2.5 mb-1.5"
          >
            <span className="w-7 shrink-0">{block.letterPrefix}.</span>
            <div className="flex-1">{block.pejabat}</div>
          </div>
        );

      case 'direktif-subpoin':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className={`flex items-start text-[11pt] leading-[1.38] mb-1.5 ${
              block.isContinuation ? 'pl-[88px]' : 'pl-[60px]'
            }`}
          >
            {!block.isContinuation && (
              <span className="w-7 shrink-0">{block.subIndex})</span>
            )}
            <p
              data-measure-text={isMeasure ? 'true' : undefined}
              className="flex-1 text-justify"
              style={justifyStyle}
            >
              {block.text}
            </p>
          </div>
        );

      case 'direktif-paragraf':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className={`flex items-start text-[11pt] leading-[1.38] mb-2 ${
              block.isContinuation ? 'pl-[60px]' : 'pl-8 mt-2.5'
            }`}
          >
            {!block.isContinuation && (
              <span className="w-7 shrink-0">{block.letterPrefix}.</span>
            )}
            <p
              data-measure-text={isMeasure ? 'true' : undefined}
              className="flex-1 text-justify"
              style={justifyStyle}
            >
              {block.pejabat}
            </p>
          </div>
        );

      case 'penutup':
        return (
          <div
            key={`b-${idx}`}
            {...wrapAttr}
            className={`flex items-start text-[11pt] leading-[1.38] mb-4 ${
              block.isContinuation ? 'pl-8' : 'mt-3'
            }`}
          >
            {!block.isContinuation && <span className="w-8 shrink-0">4.</span>}
            <p
              data-measure-text={isMeasure ? 'true' : undefined}
              className="flex-1 text-justify"
              style={justifyStyle}
            >
              {block.text}
            </p>
          </div>
        );

      case 'ttd-tembusan':
        return (
          <div key={`b-${idx}`} {...wrapAttr} className="avoid-break mt-6">
            {renderTtdAndTembusan()}
          </div>
        );

      default:
        return null;
    }
  };

  /**
   * Real DOM pixel measurement pagination:
   * Never pushes text to a new page before reaching the configured bottom margin.
   * When a long paragraph overflows the remaining space above the bottom margin,
   * splits at the exact word boundary that fills up to the bottom margin.
   */
  useLayoutEffect(() => {
    if (mode !== 'paginated') return;
    const root = measureRootRef.current;
    const bodyCal = bodyCalibratorRef.current;
    const contHdr = contHeaderMeasureRef.current;
    const probe = probeTextRef.current;
    if (!root || !bodyCal || !contHdr || !probe) return;

    const maxBodyHeightPx = bodyCal.getBoundingClientRect().height;
    if (maxBodyHeightPx <= 40) return;

    const contHdrInner = (contHdr.firstElementChild as HTMLElement | null) ?? contHdr;
    const contHdrStyle = getComputedStyle(contHdrInner);
    const contHdrHeightPx = contHdrInner.getBoundingClientRect().height;
    const contHdrMarginBottomPx = parseFloat(contHdrStyle.marginBottom || '0');

    const measureTextHeight = (text: string, widthPx: number): number => {
      probe.style.width = `${widthPx}px`;
      probe.textContent = text;
      return probe.getBoundingClientRect().height;
    };

    const nextPages: PageBlock[][] = [[]];
    let usedHeight = 0;
    let prevMb = 0;
    const pageLimit = maxBodyHeightPx;

    const startNewPage = () => {
      nextPages.push([]);
      usedHeight = contHdrHeightPx;
      prevMb = contHdrMarginBottomPx;
    };

    const placeBlockOrSplit = (
      block: PageBlock,
      elHeight: number,
      mt: number,
      mb: number,
      textWidthPx: number,
      extraTopOffset: number,
      depth = 0
    ) => {
      const currentPage = nextPages[nextPages.length - 1];
      const topGap = Math.max(prevMb, mt);
      const effectiveHeight = elHeight + extraTopOffset;

      if (usedHeight + topGap + effectiveHeight <= pageLimit + 0.5) {
        currentPage.push(block);
        usedHeight += topGap + effectiveHeight;
        prevMb = mb;
        return;
      }

      // Does not fully fit before the bottom margin.
      // Check if we can fill down to the bottom margin by splitting at a word boundary.
      const remainingPx = pageLimit - usedHeight - topGap - extraTopOffset;
      const fullText = getBlockText(block);

      if (
        isSplittableBlock(block) &&
        depth < 12 &&
        remainingPx >= 24 &&
        textWidthPx > 40 &&
        fullText.trim().length > 0
      ) {
        const words = fullText.trim().split(/\s+/);
        if (words.length >= 6) {
          let low = 1;
          let high = words.length - 1;
          let best = 0;

          while (low <= high) {
            const mid = Math.floor((low + high) / 2);
            const candidate = words.slice(0, mid).join(' ');
            const h = measureTextHeight(candidate, textWidthPx);
            if (h <= remainingPx + 0.5) {
              best = mid;
              low = mid + 1;
            } else {
              high = mid - 1;
            }
          }

          if (best >= 3 && words.length - best >= 2) {
            const firstPart = words.slice(0, best).join(' ');
            const secondPart = words.slice(best).join(' ');

            currentPage.push(
              cloneBlockWithText(block, firstPart, {
                isContinuation: block.isContinuation,
                isSplitStart: true,
              })
            );

            startNewPage();

            const contBlock = cloneBlockWithText(block, secondPart, {
              isContinuation: true,
              isSplitStart: false,
            });
            const contHeight = measureTextHeight(secondPart, textWidthPx);
            placeBlockOrSplit(contBlock, contHeight, 0, mb, textWidthPx, 0, depth + 1);
            return;
          }
        }
      }

      // Otherwise, only break to a new page when the current page already has content
      if (currentPage.length > 0) {
        startNewPage();
        const freshHeight =
          block.isContinuation && textWidthPx > 40
            ? measureTextHeight(fullText, textWidthPx)
            : elHeight;
        const freshMt = block.isContinuation ? 0 : mt;
        placeBlockOrSplit(block, freshHeight, freshMt, mb, textWidthPx, 0, depth + 1);
      } else {
        // Page is empty and block alone is taller than a whole page; place it anyway
        currentPage.push(block);
        usedHeight += effectiveHeight;
        prevMb = mb;
      }
    };

    for (let i = 0; i < rawBlocks.length; i++) {
      const block = rawBlocks[i];
      const el = root.querySelector<HTMLElement>(`[data-measure-idx="${i}"]`);
      if (!el) continue;

      const style = getComputedStyle(el);
      const mt = parseFloat(style.marginTop || '0');
      const mb = parseFloat(style.marginBottom || '0');
      const rectHeight = el.getBoundingClientRect().height;
      const textEl = el.querySelector<HTMLElement>('[data-measure-text="true"]');
      const textWidthPx = textEl ? textEl.getBoundingClientRect().width : 0;

      // Prevent orphaned header on the very last sliver (< 22px left for 1st line below)
      if (block.kind === 'direktif-header' || block.kind === 'rujukan-header') {
        const currentPage = nextPages[nextPages.length - 1];
        const topGap = Math.max(prevMb, mt);
        const remainingAfterHeader = pageLimit - (usedHeight + topGap + rectHeight);
        if (currentPage.length > 0 && remainingAfterHeader < 22) {
          startNewPage();
        }
      }

      placeBlockOrSplit(block, rectHeight, mt, mb, textWidthPx, 0);
    }

    setMeasuredPages(nextPages);
  }, [rawBlocks, margins.atas, margins.bawah, margins.kiri, margins.kanan, mode, measureTick]);

  // Re-measure if calibrator dimensions or web fonts settle after initial paint
  useEffect(() => {
    if (mode !== 'paginated') return;
    let active = true;
    const cal = bodyCalibratorRef.current;
    let lastHeight = cal ? Math.round(cal.getBoundingClientRect().height) : 0;

    let observer: ResizeObserver | null = null;
    if (cal && typeof ResizeObserver !== 'undefined') {
      observer = new ResizeObserver(() => {
        if (!active) return;
        const nextHeight = Math.round(cal.getBoundingClientRect().height);
        if (nextHeight > 40 && nextHeight !== lastHeight) {
          lastHeight = nextHeight;
          setMeasureTick((t) => t + 1);
        }
      });
      observer.observe(cal);
    }

    if (typeof document !== 'undefined' && document.fonts?.ready) {
      document.fonts.ready.then(() => {
        if (active) setMeasureTick((t) => t + 1);
      });
    }

    return () => {
      active = false;
      observer?.disconnect();
    };
  }, [mode]);

  useEffect(() => {
    if (pageRefs) {
      pageRefs.current.length = mode === 'paginated' ? measuredPages.length : 1;
    }
    if (mode === 'paginated') {
      onPageCountChange?.(measuredPages.length);
    } else {
      onPageCountChange?.(1);
    }
  }, [measuredPages.length, mode, onPageCountChange, pageRefs]);

  const hiddenMeasurementContainer =
    mode === 'paginated' && typeof document !== 'undefined'
      ? createPortal(
          <div
            ref={measureRootRef}
            aria-hidden="true"
            className="no-print letter-sheet fixed -left-[99999px] top-0 invisible pointer-events-none box-border"
            style={{
              width: '210mm',
              ...pagePaddingStyle,
            }}
          >
            <div
              ref={bodyCalibratorRef}
              style={{
                height: `calc(297mm - ${margins.atas}cm - ${margins.bawah}cm)`,
                position: 'absolute',
                top: 0,
                left: 0,
                width: '1px',
                pointerEvents: 'none',
              }}
            />
            <div ref={contHeaderMeasureRef}>{renderContinuationHeader(2)}</div>
            {rawBlocks.map((block, idx) => renderBlock(block, idx, true))}
            <p
              ref={probeTextRef}
              className="text-[11pt] leading-[1.38] text-justify m-0 p-0"
            />
          </div>,
          document.body
        )
      : null;

  const marginGuideOverlay = showMarginGuides ? (
    <div
      aria-hidden="true"
      className="no-print pointer-events-none absolute border border-dashed border-sky-400/75"
      style={{
        top: `${margins.atas}cm`,
        right: `${margins.kanan}cm`,
        bottom: `${margins.bawah}cm`,
        left: `${margins.kiri}cm`,
      }}
    />
  ) : null;

  if (mode === 'continuous') {
    return (
      <>
        <style>{dynamicPrintRule}</style>
        <div
          className="mx-auto flex flex-col items-center"
          style={{ width: `${210 * zoom}mm` }}
        >
          <article
            className="print-zoom-reset letter-sheet letter-sheet-continuous relative ring-1 ring-slate-300/80 shadow-sm"
            style={{
              ...pagePaddingStyle,
              transform: zoom !== 1 ? `scale(${zoom})` : undefined,
              transformOrigin: 'top center',
            }}
          >
            {marginGuideOverlay}
            <div className="mb-5">{renderKopAndMeta()}</div>
            {doc.rujukan.length > 0 && (
              <div className="flex items-start text-[11pt] leading-[1.38] mb-3">
                <span className="w-8 shrink-0">1.</span>
                <div className="flex-1">
                  <div className="mb-1.5">Rujukan:</div>
                  <div className="space-y-1.5">
                    {doc.rujukan.map((r, rIdx) => (
                      <div key={r.id} className="flex items-start">
                        <span className="w-7 shrink-0">
                          {String.fromCharCode(97 + rIdx)}.
                        </span>
                        <span className="flex-1 text-justify">{r.teks}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="flex items-start text-[11pt] leading-[1.38] mb-3">
              <span className="w-8 shrink-0">2.</span>
              <p className="flex-1 text-justify">{doc.latarBelakang}</p>
            </div>

            <div className="flex items-start text-[11pt] leading-[1.38] mb-2.5">
              <span className="w-8 shrink-0">3.</span>
              <p className="flex-1 text-justify">{doc.pembukaDirektif}</p>
            </div>

            {doc.direktifList.map((dir, dIdx) => {
              const letter = String.fromCharCode(97 + dIdx);
              if (dir.jenis === 'paragraf') {
                return (
                  <div
                    key={dir.id}
                    className="flex items-start text-[11pt] leading-[1.38] pl-8 mt-2.5 mb-2"
                  >
                    <span className="w-7 shrink-0">{letter}.</span>
                    <p className="flex-1 text-justify">{dir.pejabat}</p>
                  </div>
                );
              }
              return (
                <div key={dir.id} className="mt-2.5">
                  <div className="flex items-start text-[11pt] leading-[1.38] pl-8 mb-1.5">
                    <span className="w-7 shrink-0">{letter}.</span>
                    <div className="flex-1">{dir.pejabat}</div>
                  </div>
                  {dir.poin.map((sub, sIdx) => (
                    <div
                      key={sub.id}
                      className="flex items-start text-[11pt] leading-[1.38] pl-[60px] mb-1.5"
                    >
                      <span className="w-7 shrink-0">{sIdx + 1})</span>
                      <p className="flex-1 text-justify">{sub.teks}</p>
                    </div>
                  ))}
                </div>
              );
            })}

            <div className="flex items-start text-[11pt] leading-[1.38] mt-3 mb-4">
              <span className="w-8 shrink-0">4.</span>
              <p className="flex-1 text-justify">{doc.penutup}</p>
            </div>

            <div className="avoid-break mt-6">{renderTtdAndTembusan()}</div>
          </article>
        </div>
      </>
    );
  }

  return (
    <>
      <style>{dynamicPrintRule}</style>
      {hiddenMeasurementContainer}
      <div
        className={`mx-auto w-fit ${
          columns === 2 && measuredPages.length > 1
            ? 'grid grid-cols-1 lg:grid-cols-2 gap-8 items-start'
            : 'flex flex-col items-center gap-6'
        }`}
      >
        {measuredPages.map((pageBlocks, pIdx) => (
          <div key={`page-wrap-${pIdx}`} className="flex flex-col items-center gap-1.5">
            {showPageLabels && (
              <div
                className="no-print flex items-center justify-between px-0.5 text-[11px] font-mono-code text-slate-500"
                style={{ width: `${210 * zoom}mm` }}
              >
                <span>
                  Halaman {pIdx + 1} / {measuredPages.length}
                </span>
                <span>A4 · 210 × 297 mm</span>
              </div>
            )}
            <div
              className="print-page-slot shrink-0"
              style={{
                width: `${210 * zoom}mm`,
                height: `${297 * zoom}mm`,
              }}
            >
              <article
                ref={(el) => {
                  if (pageRefs) pageRefs.current[pIdx] = el;
                }}
                className="print-zoom-reset letter-sheet letter-sheet-page relative ring-1 ring-slate-300/80 shadow-[0_2px_12px_rgba(15,23,42,0.08)]"
                style={{
                  ...pagePaddingStyle,
                  transform: zoom !== 1 ? `scale(${zoom})` : undefined,
                  transformOrigin: 'top left',
                }}
                aria-label={`Halaman ${pIdx + 1}`}
              >
                {marginGuideOverlay}
                {pIdx > 0 && renderContinuationHeader(pIdx + 1)}
                {pageBlocks.map((block, bIdx) => renderBlock(block, bIdx, false))}
              </article>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

interface DocumentPreviewModalProps {
  doc: LetterDocument;
  onClose: () => void;
  onUseTemplate?: (doc: LetterDocument) => void;
  onPrint?: () => void;
}

export const DocumentPreviewModal: React.FC<DocumentPreviewModalProps> = ({
  doc,
  onClose,
  onUseTemplate,
  onPrint,
}) => {
  const [zoom, setZoom] = useState(1);
  const [columns, setColumns] = useState<1 | 2>(1);
  const [showMarginGuides, setShowMarginGuides] = useState(false);
  const [pageCount, setPageCount] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);
  const [copied, setCopied] = useState(false);
  const [exporting, setExporting] = useState<'docx' | 'pdf' | null>(null);

  const viewportRef = useRef<HTMLDivElement | null>(null);
  const pageRefs = useRef<(HTMLElement | null)[]>([]);
  const nomorLengkap = formatNomorSurat(doc.identitas);
  const margins = doc.margins ?? DEFAULT_MARGINS;

  const jumpToPage = (pageNum: number) => {
    const clamped = Math.min(Math.max(1, pageNum), pageCount);
    setCurrentPage(clamped);
    const target = pageRefs.current[clamped - 1];
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Lock body scroll while modal is open & support keyboard shortcuts
  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable)
      ) {
        return;
      }

      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      } else if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        e.preventDefault();
        jumpToPage(currentPage + 1);
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        jumpToPage(currentPage - 1);
      } else if (e.key === '=' || e.key === '+') {
        e.preventDefault();
        setZoom((z) => Math.min(1.4, Number((z + 0.1).toFixed(2))));
      } else if (e.key === '-') {
        e.preventDefault();
        setZoom((z) => Math.max(0.5, Number((z - 0.1).toFixed(2))));
      } else if (e.key === '0') {
        e.preventDefault();
        setZoom(1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose, currentPage, pageCount]);

  // Reset to 1 column if document has only 1 page
  useEffect(() => {
    if (pageCount <= 1 && columns === 2) {
      setColumns(1);
    }
  }, [pageCount, columns]);

  // Track currently visible page while scrolling
  const handleViewportScroll = () => {
    const container = viewportRef.current;
    if (!container) return;
    const containerTop = container.getBoundingClientRect().top;
    const targetAnchor = containerTop + container.clientHeight * 0.25;

    let closestPage = 1;
    let bestDist = Number.POSITIVE_INFINITY;
    for (let i = 0; i < pageCount; i++) {
      const el = pageRefs.current[i];
      if (!el) continue;
      const rect = el.getBoundingClientRect();
      const dist = Math.abs(rect.top - targetAnchor);
      if (dist < bestDist) {
        bestDist = dist;
        closestPage = i + 1;
      }
    }
    setCurrentPage(closestPage);
  };

  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(letterToPlainText(doc));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleDownloadDocx = async () => {
    if (exporting) return;
    setExporting('docx');
    try {
      await exportLetterToDocx(doc);
    } finally {
      setExporting(null);
    }
  };

  const handleDownloadPdf = async () => {
    if (exporting) return;
    setExporting('pdf');
    try {
      await exportLetterToPdf(doc);
    } finally {
      setExporting(null);
    }
  };

  return (
    <div
      className="no-print fixed inset-0 z-50 bg-slate-900/75 backdrop-blur-[2px] flex flex-col"
      role="dialog"
      aria-modal="true"
      aria-label="Pratinjau Penuh Surat"
    >
      {/* Modal Primary Header Bar */}
      <div className="min-h-14 px-4 sm:px-5 py-2 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="min-w-0">
          <div className="text-sm font-semibold text-slate-900 truncate">
            Pratinjau Penuh — {doc.title}
          </div>
          <div className="text-xs text-slate-500 font-mono-code truncate">
            {nomorLengkap} · {pageCount} Halaman A4 · Margin {margins.kiri}/{margins.atas}/
            {margins.kanan}/{margins.bawah} cm
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap shrink-0">
          {/* Layout Mode (1 Kolom vs 2 Kolom) */}
          {pageCount > 1 && (
            <div className="hidden lg:flex items-center gap-0.5 p-0.5 bg-slate-100 rounded-md mr-1">
              <button
                type="button"
                onClick={() => setColumns(1)}
                className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded whitespace-nowrap cursor-pointer transition-colors ${
                  columns === 1
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Square className="w-3 h-3" aria-hidden="true" />
                <span>1 Kolom</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setColumns(2);
                  setZoom((z) => (z > 0.8 ? 0.7 : z));
                }}
                className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded whitespace-nowrap cursor-pointer transition-colors ${
                  columns === 2
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Columns2 className="w-3 h-3" aria-hidden="true" />
                <span>2 Kolom</span>
              </button>
            </div>
          )}

          {/* Margin Guides Toggle */}
          <button
            type="button"
            onClick={() => setShowMarginGuides((v) => !v)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md border whitespace-nowrap cursor-pointer transition-colors ${
              showMarginGuides
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:text-slate-900'
            }`}
          >
            <Ruler className="w-3.5 h-3.5" aria-hidden="true" />
            <span className="hidden sm:inline">Garis Margin</span>
          </button>

          {/* Zoom Controls */}
          <div className="flex items-center gap-0.5 text-xs text-slate-600 border-x border-slate-200 px-2">
            <button
              type="button"
              onClick={() => setZoom((z) => Math.max(0.5, Number((z - 0.1).toFixed(2))))}
              aria-label="Perkecil pratinjau"
              className="p-1.5 hover:text-slate-900 rounded cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setZoom(1)}
              title="Kembalikan ke 100%"
              className="w-11 py-1 text-center font-mono-code tabular-nums hover:bg-slate-100 rounded cursor-pointer"
            >
              {Math.round(zoom * 100)}%
            </button>
            <button
              type="button"
              onClick={() => setZoom((z) => Math.min(1.4, Number((z + 0.1).toFixed(2))))}
              aria-label="Perbesar pratinjau"
              className="p-1.5 hover:text-slate-900 rounded cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            type="button"
            onClick={handleCopyText}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap cursor-pointer"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
            ) : (
              <Copy className="w-3.5 h-3.5" aria-hidden="true" />
            )}
            <span className="hidden sm:inline">{copied ? 'Tersalin' : 'Salin'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadDocx}
            disabled={exporting !== null}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            <FileDown className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{exporting === 'docx' ? 'Menyiapkan...' : 'Unduh .docx'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPdf}
            disabled={exporting !== null}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            <FileDown className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{exporting === 'pdf' ? 'Menyiapkan...' : 'Unduh .pdf'}</span>
          </button>

          {onPrint && (
            <button
              type="button"
              onClick={onPrint}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" aria-hidden="true" />
              <span className="hidden md:inline">Cetak</span>
            </button>
          )}

          {onUseTemplate && (
            <button
              type="button"
              onClick={() => {
                onUseTemplate(doc);
                onClose();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap cursor-pointer"
            >
              <span>Gunakan di Editor</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            aria-label="Keluar dari pratinjau penuh"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 hover:text-slate-900 border border-slate-200 rounded-md whitespace-nowrap cursor-pointer transition-colors"
          >
            <X className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Keluar</span>
          </button>
        </div>
      </div>

      {/* Page Navigation Bar for Multi-page Documents */}
      {pageCount > 1 && (
        <div className="px-4 sm:px-5 py-1.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between gap-3 shrink-0 overflow-x-auto workspace-scroll">
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => jumpToPage(currentPage - 1)}
              disabled={currentPage <= 1}
              aria-label="Halaman sebelumnya"
              className="p-1 rounded border border-slate-200 bg-white text-slate-700 hover:text-slate-900 disabled:opacity-40 cursor-pointer disabled:cursor-default"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span className="text-xs font-mono-code tabular-nums text-slate-700 px-1.5 whitespace-nowrap">
              Halaman {currentPage} / {pageCount}
            </span>
            <button
              type="button"
              onClick={() => jumpToPage(currentPage + 1)}
              disabled={currentPage >= pageCount}
              aria-label="Halaman berikutnya"
              className="p-1 rounded border border-slate-200 bg-white text-slate-700 hover:text-slate-900 disabled:opacity-40 cursor-pointer disabled:cursor-default"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex items-center gap-1">
            {Array.from({ length: pageCount }, (_, idx) => {
              const pageNum = idx + 1;
              return (
                <button
                  key={`modal-jump-${pageNum}`}
                  type="button"
                  onClick={() => jumpToPage(pageNum)}
                  className={`px-2 py-0.5 text-[11px] font-mono-code tabular-nums rounded whitespace-nowrap transition-colors cursor-pointer ${
                    currentPage === pageNum
                      ? 'bg-slate-900 text-white'
                      : 'bg-white text-slate-600 border border-slate-200 hover:text-slate-900'
                  }`}
                >
                  {pageNum}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Scrollable Modal Body */}
      <div
        ref={viewportRef}
        onScroll={handleViewportScroll}
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
        className="flex-1 overflow-auto workspace-scroll bg-slate-200/95 py-8 px-4 sm:px-8"
      >
        <LetterDocumentPages
          doc={doc}
          mode="paginated"
          zoom={zoom}
          columns={columns}
          showMarginGuides={showMarginGuides}
          showPageLabels={true}
          pageRefs={pageRefs}
          onPageCountChange={setPageCount}
        />
      </div>
    </div>
  );
};
