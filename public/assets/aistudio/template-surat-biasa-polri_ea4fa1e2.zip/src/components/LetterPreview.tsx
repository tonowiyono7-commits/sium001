import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  FileDown,
  Maximize2,
  Save,
} from 'lucide-react';
import { LetterDocument } from '../types/letter';
import { letterToPlainText } from '../utils/exportDoc';
import { exportLetterToDocx } from '../utils/exportDocx';
import { exportLetterToPdf } from '../utils/exportPdf';
import {
  DocumentPreviewModal,
  LetterDocumentPages,
} from './LetterDocumentPages';

interface LetterPreviewProps {
  doc: LetterDocument;
  onSaveDraft: () => void;
  draftSavedJustNow: boolean;
  onPrint?: () => void;
}

const A4_WIDTH_PX = 794;

export const LetterPreview: React.FC<LetterPreviewProps> = ({
  doc,
  onSaveDraft,
  draftSavedJustNow,
  onPrint,
}) => {
  const [copied, setCopied] = useState(false);
  const [fullPreviewOpen, setFullPreviewOpen] = useState(false);
  const [activePageJump, setActivePageJump] = useState<number>(0);
  const [pageCount, setPageCount] = useState<number>(1);
  const [containerWidth, setContainerWidth] = useState<number>(900);
  const [exporting, setExporting] = useState<'docx' | 'pdf' | null>(null);

  const viewportRef = useRef<HTMLDivElement | null>(null);
  const pageRefs = useRef<(HTMLElement | null)[]>([]);

  useEffect(() => {
    const el = viewportRef.current;
    if (!el) return;

    const update = () => {
      if (el.clientWidth > 0) {
        setContainerWidth(el.clientWidth);
      }
    };
    update();

    if (typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(update);
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (activePageJump >= pageCount) {
      setActivePageJump(Math.max(0, pageCount - 1));
    }
  }, [pageCount, activePageJump]);

  const responsiveZoom = useMemo(() => {
    const available = Math.max(280, containerWidth - 32);
    const fit = Math.min(1, Math.max(0.42, available / A4_WIDTH_PX));
    return Number(fit.toFixed(3));
  }, [containerWidth]);

  const handleViewportScroll = () => {
    const container = viewportRef.current;
    if (!container) return;
    const anchorY = container.getBoundingClientRect().top + container.clientHeight * 0.25;
    let bestIdx = 0;
    let bestDist = Number.POSITIVE_INFINITY;
    for (let i = 0; i < pageCount; i++) {
      const el = pageRefs.current[i];
      if (!el) continue;
      const dist = Math.abs(el.getBoundingClientRect().top - anchorY);
      if (dist < bestDist) {
        bestDist = dist;
        bestIdx = i;
      }
    }
    setActivePageJump(bestIdx);
  };

  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(letterToPlainText(doc));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback ignored if clipboard permission denied
    }
  };

  const handleDownloadDocx = async () => {
    if (exporting) return;
    setExporting('docx');
    try {
      await exportLetterToDocx(doc);
    } finally {
      setExporting(null);
    }
  };

  const handleDownloadPdf = async () => {
    if (exporting) return;
    setExporting('pdf');
    try {
      await exportLetterToPdf(doc);
    } finally {
      setExporting(null);
    }
  };

  const handleJumpToPage = (idx: number) => {
    setActivePageJump(idx);
    const target = pageRefs.current[idx];
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-100">
      {/* Workspace Preview Toolbar */}
      <div className="no-print min-h-12 px-4 py-1.5 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="text-xs font-medium text-slate-600 font-mono-code tabular-nums">
          Pratinjau A4 · {pageCount} Halaman
        </div>

        {/* Export & Full Preview Actions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => setFullPreviewOpen(true)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Pratinjau Penuh</span>
          </button>

          <button
            type="button"
            onClick={handleCopyText}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
            ) : (
              <Copy className="w-3.5 h-3.5" aria-hidden="true" />
            )}
            <span>{copied ? 'Tersalin' : 'Salin'}</span>
          </button>

          <button
            type="button"
            onClick={onSaveDraft}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:border-slate-300 hover:text-slate-900 rounded-md whitespace-nowrap transition-colors cursor-pointer"
          >
            {draftSavedJustNow ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" aria-hidden="true" />
            ) : (
              <Save className="w-3.5 h-3.5" aria-hidden="true" />
            )}
            <span>{draftSavedJustNow ? 'Tersimpan' : 'Simpan'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadDocx}
            disabled={exporting !== null}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-md whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
          >
            <FileDown className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{exporting === 'docx' ? 'Menyiapkan...' : 'Unduh .docx'}</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPdf}
            disabled={exporting !== null}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md whitespace-nowrap transition-colors cursor-pointer disabled:opacity-50"
          >
            <FileDown className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{exporting === 'pdf' ? 'Menyiapkan...' : 'Unduh .pdf'}</span>
          </button>
        </div>
      </div>

      {/* Quick Page Navigator for Multi-Page Letters */}
      {pageCount > 1 && (
        <div className="no-print px-4 py-1.5 bg-slate-50 border-b border-slate-200 flex items-center gap-1.5 overflow-x-auto workspace-scroll shrink-0">
          <span className="text-[11px] font-medium text-slate-500 whitespace-nowrap mr-1">
            Lompat Halaman:
          </span>
          {Array.from({ length: pageCount }, (_, idx) => (
            <button
              key={`jump-${idx}`}
              type="button"
              onClick={() => handleJumpToPage(idx)}
              className={`px-2 py-0.5 text-[11px] font-mono-code tabular-nums rounded whitespace-nowrap transition-colors cursor-pointer ${
                activePageJump === idx
                  ? 'bg-slate-900 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:text-slate-900'
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>
      )}

      {/* Preview Canvas */}
      <div
        ref={viewportRef}
        onScroll={handleViewportScroll}
        className="flex-1 overflow-auto workspace-scroll py-6 px-4 print-only-container"
      >
        <LetterDocumentPages
          doc={doc}
          mode="paginated"
          zoom={responsiveZoom}
          showPageLabels={true}
          pageRefs={pageRefs}
          onPageCountChange={setPageCount}
        />
      </div>

      {fullPreviewOpen && (
        <DocumentPreviewModal
          doc={doc}
          onClose={() => setFullPreviewOpen(false)}
          onPrint={onPrint}
        />
      )}
    </div>
  );
};
