import React from 'react';

interface TribrataEmblemProps {
  className?: string;
}

export const TRIBRATA_IMAGE_URL =
  '/assets/aistudio/1000969864-removebg-preview_072d2c01.png';

/**
 * Official monochrome Tribrata emblem for Polri Kop Surat.
 */
export const TribrataEmblem: React.FC<TribrataEmblemProps> = ({
  className = 'h-14 w-auto',
}) => {
  return (
    <img
      src={TRIBRATA_IMAGE_URL}
      alt="Lambang Tribrata"
      width={200}
      height={181}
      className={`object-contain select-none ${className}`}
    />
  );
};

interface OfficialStampProps {
  satuan?: string;
  jabatan?: string;
  className?: string;
}

/**
 * Circular official stamp preview matching page 12 of the reference document.
 */
export const OfficialStamp: React.FC<OfficialStampProps> = ({
  satuan = 'DAERAH JAWA TENGAH',
  jabatan = 'KAROOPS',
  className = 'w-28 h-28',
}) => {
  const cleanSatuan = satuan.split('\n')[0].toUpperCase().slice(0, 24);
  const cleanJabatan = jabatan.toUpperCase().slice(0, 16);

  return (
    <svg
      viewBox="0 0 140 140"
      className={className}
      aria-label="Pratinjau Stempel Dinas"
    >
      <defs>
        <path id="stampTopArc" d="M 22,70 A 48,48 0 1,1 118,70" />
        <path id="stampBottomArc" d="M 22,74 A 48,48 0 0,0 118,74" />
      </defs>
      {/* Outer double ring */}
      <circle cx="70" cy="70" r="64" fill="none" stroke="#1e3a8a" strokeWidth="2.4" opacity="0.72" />
      <circle cx="70" cy="70" r="60" fill="none" stroke="#1e3a8a" strokeWidth="1.1" opacity="0.72" />
      {/* Inner circle */}
      <circle cx="70" cy="70" r="36" fill="none" stroke="#1e3a8a" strokeWidth="1.5" opacity="0.72" />

      {/* Top curved text */}
      <text
        fill="#1e3a8a"
        fontSize="7.4"
        fontWeight="700"
        letterSpacing="0.8"
        opacity="0.78"
        fontFamily="Arial, sans-serif"
      >
        <textPath href="#stampTopArc" startOffset="50%" textAnchor="middle">
          KEPOLISIAN NEGARA REPUBLIK INDONESIA
        </textPath>
      </text>

      {/* Bottom curved text */}
      <text
        fill="#1e3a8a"
        fontSize="7.4"
        fontWeight="700"
        letterSpacing="0.8"
        opacity="0.78"
        fontFamily="Arial, sans-serif"
      >
        <textPath href="#stampBottomArc" startOffset="50%" textAnchor="middle">
          {cleanSatuan}
        </textPath>
      </text>

      {/* Center Jabatan */}
      <text
        x="70"
        y="74"
        textAnchor="middle"
        fill="#1e3a8a"
        fontSize="10.5"
        fontWeight="700"
        letterSpacing="0.5"
        opacity="0.82"
        fontFamily="Arial, sans-serif"
      >
        {cleanJabatan}
      </text>

      {/* Subtle diagonal signature stroke */}
      <path
        d="M 20 118 C 44 92, 68 62, 108 26 M 62 66 C 72 60, 82 54, 92 64 C 84 74, 72 78, 66 72"
        fill="none"
        stroke="#0f172a"
        strokeWidth="2.6"
        strokeLinecap="round"
        opacity="0.85"
      />
    </svg>
  );
};
