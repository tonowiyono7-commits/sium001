import React from 'react';
import { Printer } from 'lucide-react';
import { ActiveWorkspaceTab } from '../types/letter';

interface TopBarProps {
  activeTab: ActiveWorkspaceTab;
  onSelectTab: (tab: ActiveWorkspaceTab) => void;
  onPrint: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ activeTab, onSelectTab, onPrint }) => {
  const navItems: { id: ActiveWorkspaceTab; label: string }[] = [
    { id: 'editor', label: 'Editor Surat' },
    { id: 'analysis', label: 'Analisis Dokumen' },
    { id: 'templates', label: 'Pustaka Template' },
  ];

  return (
    <header className="no-print sticky top-0 z-30 h-14 bg-white border-b border-slate-200 px-6 flex items-center justify-between gap-8">
      {/* Zone 1: Brand wordmark (1 line, no descriptor/badge) */}
      <button
        type="button"
        onClick={() => onSelectTab('editor')}
        className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-slate-900"
      >
        Naskah Dinas
      </button>

      {/* Zone 2: Clean single-line text navigation links */}
      <nav className="flex items-center gap-6 h-full" aria-label="Navigasi utama">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`relative h-full px-1 text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900 ${
                isActive ? 'text-slate-900' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {item.label}
              {isActive && (
                <span
                  aria-hidden="true"
                  className="absolute inset-x-0 bottom-0 h-0.5 bg-slate-900"
                />
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Single primary CTA */}
      <div className="shrink-0">
        <button
          type="button"
          onClick={onPrint}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-slate-900"
        >
          <Printer className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Cetak / PDF</span>
        </button>
      </div>
    </header>
  );
};
